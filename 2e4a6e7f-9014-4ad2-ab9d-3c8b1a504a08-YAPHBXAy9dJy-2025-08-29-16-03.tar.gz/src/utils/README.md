# Level Normalizer

The enhanced level normalizer provides intelligent, context-aware level detection for construction drawings and takeoff data.

## Features

- **Weighted scoring system** for more accurate level detection
- **Context awareness** - sheet titles, IDs, and legends get scoring boosts
- **Comprehensive pattern matching** covering international notation and abbreviations
- **Backward compatibility** with existing code
- **Robust error handling** for edge cases

## Basic Usage

```typescript
import { normalizeLevel, normalizeLevelScored, inferLevelFromSheet } from './levels';

// Simple level normalization
const level = normalizeLevel('First Floor'); // Returns 'GROUND FLOOR'

// Get detailed scoring information
const result = normalizeLevelScored('FFE +0\'-0"');
// Returns: { level: 'FOUNDATION', score: 7 }

// Infer level from sheet information
const sheetLevel = inferLevelFromSheet('A1.1', 'First Floor Plan');
// Returns: 'GROUND FLOOR'
```

## Advanced Usage with Context

```typescript
// Boost scoring for sheet titles
const titleResult = normalizeLevelScored('First Floor', { 
  isSheetTitle: true 
});

// Boost scoring for sheet IDs
const idResult = normalizeLevelScored('L1', { 
  isSheetId: true 
});

// Boost scoring for legends/indexes
const legendResult = normalizeLevelScored('Level 2', { 
  isIndexOrLegend: true 
});
```

## Supported Level Types

- **FOUNDATION**: Basement, crawl space, slab on grade, parking levels
- **GROUND FLOOR**: First floor, ground floor, level 1, main level
- **SECOND FLOOR**: Second floor, upper floors, levels 2-9
- **ROOF**: Roof plan, attic, ridge, top of plate/wall
- **UNKNOWN**: Unrecognized or ambiguous levels

## Pattern Examples

### Foundation
- `FFE +0'-0"`, `TOS`, `SOG`, `basement`, `P1`, `B2`
- Sheet titles containing "Foundation Plan"

### Ground Floor
- `First Floor`, `Ground Floor`, `L1`, `01`, `1F`
- Sheet titles like "A1.1 – First Floor Plan"

### Second Floor
- `Second Floor`, `L2`, `02`, `2F`, `L3`, `3rd Floor`
- Sheet titles like "A1.2 – Second Floor Plan"

### Roof
- `Roof Plan`, `Ridge`, `TOP`, `TOW`, `Attic`
- Sheet titles containing "Roof Plan"

## Context Scoring

The system applies multipliers based on context:
- **Sheet Title**: +75% score boost (strongest signal)
- **Sheet ID**: +35% score boost (modest signal)
- **Legend/Index**: +25% score boost (weakest signal)

## Migration from Old System

The enhanced normalizer is fully backward compatible. Existing code will continue to work:

```typescript
// Old code - still works
import { normalizeLevel } from './levels';
const level = normalizeLevel('L1');

// New enhanced features available
import { normalizeLevelScored } from './levels';
const result = normalizeLevelScored('L1', { isSheetId: true });
```

## Testing

Run the test suite to verify functionality:

```bash
npm test src/test/level-normalizer.test.ts
```

## Performance

- **Fast pattern matching** using optimized regex patterns
- **Efficient scoring** with minimal memory allocation
- **Deterministic results** for consistent behavior
- **Handles edge cases** gracefully without crashes

