import AsyncStorage from "@react-native-async-storage/async-storage";
import { StateStorage } from "zustand/middleware";

interface StorageOptions {
  onError?: (error: Error, key: string) => void;
  validateState?: (state: any) => boolean;
}

/**
 * Creates a robust JSON storage that handles malformed JSON gracefully
 * Prevents app crashes from corrupted AsyncStorage data
 */
export function createRobustJSONStorage(options: StorageOptions = {}): StateStorage {
  const { onError, validateState } = options;

  return {
    getItem: async (name: string): Promise<string | null> => {
      try {
        const item = await AsyncStorage.getItem(name);
        if (!item) return null;

        // Test if JSON is valid by parsing it
        const parsed = JSON.parse(item);
        
        // Optional state validation
        if (validateState && !validateState(parsed)) {
          console.warn(`[StorageUtils] Invalid state structure for ${name}, clearing corrupted data`);
          await AsyncStorage.removeItem(name);
          return null;
        }

        return item;
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : "Unknown error";
        console.warn(`[StorageUtils] Failed to parse stored data for ${name}: ${errorMessage}`);
        
        // Call optional error handler
        if (onError && error instanceof Error) {
          onError(error, name);
        }

        // Clear corrupted data to prevent repeated errors
        try {
          await AsyncStorage.removeItem(name);
        } catch (clearError) {
          console.warn(`[StorageUtils] Failed to clear corrupted data for ${name}`);
        }

        // Return null to trigger default state
        return null;
      }
    },

    setItem: async (name: string, value: string): Promise<void> => {
      try {
        await AsyncStorage.setItem(name, value);
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : "Unknown error";
        console.warn(`[StorageUtils] Failed to save data for ${name}: ${errorMessage}`);
        
        if (onError && error instanceof Error) {
          onError(error, name);
        }
        
        // Don't throw - let the app continue without persistence
      }
    },

    removeItem: async (name: string): Promise<void> => {
      try {
        await AsyncStorage.removeItem(name);
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : "Unknown error";
        console.warn(`[StorageUtils] Failed to remove data for ${name}: ${errorMessage}`);
        
        if (onError && error instanceof Error) {
          onError(error, name);
        }
      }
    },
  };
}

/**
 * Validates pricing preferences structure
 */
export function validatePricingPreferences(state: any): boolean {
  if (!state || typeof state !== "object") return false;
  
  // Check for required preferences structure
  if (!state.preferences || typeof state.preferences !== "object") return false;
  
  const prefs = state.preferences;
  
  // Validate defaultLocation exists and has required fields
  if (!prefs.defaultLocation || typeof prefs.defaultLocation !== "object") return false;
  if (!prefs.defaultLocation.city || !prefs.defaultLocation.state) return false;
  if (typeof prefs.defaultLocation.costIndex !== "number") return false;
  
  // Validate arrays exist (can be empty)
  if (!Array.isArray(prefs.preferredSuppliers)) return false;
  
  // Validate numeric fields
  if (typeof prefs.maxPriceAge !== "number") return false;
  if (typeof prefs.confidenceThreshold !== "number") return false;
  if (typeof prefs.budgetBuffer !== "number") return false;
  
  // Validate boolean fields
  if (typeof prefs.enableLiveRetail !== "boolean") return false;
  if (typeof prefs.enableBaseline !== "boolean") return false;
  
  // Validate wasteFactorOverrides is an object
  if (!prefs.wasteFactorOverrides || typeof prefs.wasteFactorOverrides !== "object") return false;
  
  return true;
}

/**
 * Validates construction store structure
 */
export function validateConstructionState(state: any): boolean {
  if (!state || typeof state !== "object") return false;
  
  // Check for required projects array
  if (!Array.isArray(state.projects)) return false;
  
  // Validate each project has required fields
  for (const project of state.projects) {
    if (!project || typeof project !== "object") return false;
    if (!project.id || typeof project.id !== "string") return false;
    if (!project.name || typeof project.name !== "string") return false;
    if (!project.address || typeof project.address !== "string") return false;
    if (!Array.isArray(project.levels)) return false;
    if (!Array.isArray(project.documents)) return false;
    if (!Array.isArray(project.takeoffs)) return false;
  }
  
  // Check for constructionStandards
  if (!state.constructionStandards || typeof state.constructionStandards !== "object") return false;
  
  const standards = state.constructionStandards;
  if (typeof standards.studSpacingDefault !== "number") return false;
  if (typeof standards.cornerStudCount !== "number") return false;
  if (typeof standards.tIntersectionStudCount !== "number") return false;
  if (typeof standards.headerBearing !== "number") return false;
  
  // Validate wasteFactors object
  if (!standards.wasteFactors || typeof standards.wasteFactors !== "object") return false;
  
  return true;
}

/**
 * Clears all storage keys for a fresh start (emergency recovery)
 */
export async function clearAllStorageKeys(): Promise<void> {
  try {
    const keys = await AsyncStorage.getAllKeys();
    const appKeys = keys.filter(key => 
      key.includes("dual-pricing-storage") || 
      key.includes("construction-storage")
    );
    
    if (appKeys.length > 0) {
      await AsyncStorage.multiRemove(appKeys);
      console.warn(`[StorageUtils] Cleared ${appKeys.length} corrupted storage keys`);
    }
  } catch (error) {
    console.warn("[StorageUtils] Failed to clear storage keys:", error);
  }
}