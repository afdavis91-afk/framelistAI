import { TakeoffLineItem, EnrichmentContext, TakeoffFlag } from "../../../types/construction";
import { 
  getHeaderAssumption, 
  getConnectorAssumption, 
  getNailingPattern,
  generateStructuralReasoning,
  REGIONAL_DEFAULTS
} from "./assumptions";

export interface StructuralInference {
  field: string;
  originalValue: any;
  inferredValue: any;
  confidence: number;
  reasoning: string;
  assumptions: string[];
}

export interface StructuralReasoningResult {
  inferences: StructuralInference[];
  flags: TakeoffFlag[];
  confidence: number;
  assumptionsApplied: number;
}

export class StructuralReasoningModule {
  /**
   * Apply structural reasoning to fill gaps when S-series plans are missing
   */
  async applyStructuralReasoning(
    lineItems: TakeoffLineItem[],
    context: EnrichmentContext
  ): Promise<StructuralReasoningResult> {
    const inferences: StructuralInference[] = [];
    const flags: TakeoffFlag[] = [];
    let assumptionsApplied = 0;

    // Check if we have any structural documents
    const hasStructuralPlans = this.hasStructuralDocuments(context);
    
    if (!hasStructuralPlans) {
      flags.push({
        type: "ASSUMPTION",
        message: "No structural plans (S-series) found. Using intelligent reasoning to infer structural requirements from architectural plans and building codes.",
        severity: "low",
        sheets: ["All"],
        resolved: false,
      });
    }

    // Process each line item for structural reasoning
    for (const item of lineItems) {
      const itemInferences = await this.processLineItem(item, context, hasStructuralPlans);
      inferences.push(...itemInferences);
      assumptionsApplied += itemInferences.length;
    }

    // Generate additional structural elements that might be missing
    const additionalInferences = await this.inferMissingStructuralElements(lineItems, context);
    inferences.push(...additionalInferences);
    assumptionsApplied += additionalInferences.length;

    const confidence = this.calculateConfidence(inferences, hasStructuralPlans);

    return {
      inferences,
      flags,
      confidence,
      assumptionsApplied,
    };
  }

  /**
   * Check if structural documents are available
   */
  private hasStructuralDocuments(context: EnrichmentContext): boolean {
    return context.projectDocuments.some(doc => 
      doc.type === "structural" ||
      doc.name.toLowerCase().includes("struct") ||
      /S\d+/i.test(doc.name) || // S1, S2, S3, etc.
      doc.name.toLowerCase().includes("framing") ||
      doc.name.toLowerCase().includes("details") ||
      doc.name.toLowerCase().includes("schedule")
    );
  }

  /**
   * Process individual line item for structural reasoning
   */
  private async processLineItem(
    item: TakeoffLineItem,
    _context: EnrichmentContext,
    _hasStructuralPlans: boolean
  ): Promise<StructuralInference[]> {
    const inferences: StructuralInference[] = [];
    const scope = item.context.scope.toLowerCase();

    // Infer header schedules for openings
    if (scope.includes("header") || scope.includes("opening")) {
      const headerInference = this.inferHeaderSchedule(item);
      if (headerInference) {
        inferences.push(headerInference);
      }
    }

    // Infer connector details for structural connections
    if (scope.includes("connector") || scope.includes("hanger") || scope.includes("anchor")) {
      const connectorInference = this.inferConnectorDetails(item);
      if (connectorInference) {
        inferences.push(connectorInference);
      }
    }

    // Infer nailing patterns for sheathing and framing
    if (scope.includes("sheathing") || scope.includes("nail") || scope.includes("fastener")) {
      const nailingInference = this.inferNailingPatterns(item);
      if (nailingInference) {
        inferences.push(nailingInference);
      }
    }

    // Infer missing species and grades
    if (!item.material.species || item.material.species === "Unknown") {
      inferences.push(this.inferSpecies(item));
    }

    if (!item.material.grade || item.material.grade === "Unknown") {
      inferences.push(this.inferGrade(item));
    }

    return inferences;
  }

  /**
   * Infer header schedule based on opening width
   */
  private inferHeaderSchedule(item: TakeoffLineItem): StructuralInference | null {
    // Try to extract opening width from context or assumptions
    const openingWidth = this.extractOpeningWidth(item);
    if (!openingWidth) return null;

    const headerAssumption = getHeaderAssumption(openingWidth);
    if (!headerAssumption) return null;

    const inferredSpec = headerAssumption.plies > 1 
      ? `(${headerAssumption.plies}) ${headerAssumption.size}`
      : headerAssumption.size;

    return {
      field: "material.spec",
      originalValue: item.material.spec,
      inferredValue: inferredSpec,
      confidence: headerAssumption.confidence,
      reasoning: generateStructuralReasoning("header", {
        size: headerAssumption.size,
        span: openingWidth,
        plies: headerAssumption.plies
      }),
      assumptions: [
        `Header size based on ${openingWidth}" opening width`,
        `${headerAssumption.species} ${headerAssumption.grade} assumed for structural adequacy`
      ]
    };
  }

  /**
   * Infer connector details based on member size and application
   */
  private inferConnectorDetails(item: TakeoffLineItem): StructuralInference | null {
    const memberSize = item.material.size || this.inferMemberSize(item);
    const application = this.inferConnectorApplication(item);
    
    if (!memberSize || !application) return null;

    const connectorAssumption = getConnectorAssumption(memberSize, application);
    if (!connectorAssumption) return null;

    return {
      field: "material.connectorType",
      originalValue: (item.material as any).connectorType,
      inferredValue: connectorAssumption.model,
      confidence: connectorAssumption.confidence,
      reasoning: generateStructuralReasoning("connector", {
        connectorType: connectorAssumption.connectorType,
        model: connectorAssumption.model,
        memberSize: memberSize,
        application: application,
        loadRating: connectorAssumption.loadRating
      }),
      assumptions: [
        `${connectorAssumption.connectorType} assumed for ${memberSize} ${application}`,
        `Load rating: ${connectorAssumption.loadRating} lbs capacity`
      ]
    };
  }

  /**
   * Infer nailing patterns based on material and application
   */
  private inferNailingPatterns(item: TakeoffLineItem): StructuralInference | null {
    const material = this.inferSheathingMaterial(item);
    const application = this.inferNailingApplication(item);
    
    if (!material || !application) return null;

    const nailingPattern = getNailingPattern(material, application);
    if (!nailingPattern) return null;

    return {
      field: "material.nailingPattern",
      originalValue: (item.material as any).nailingPattern,
      inferredValue: `${nailingPattern.fastenerSize} ${nailingPattern.fastenerType} @ ${nailingPattern.edgeSpacing} edges, ${nailingPattern.fieldSpacing} field`,
      confidence: nailingPattern.confidence,
      reasoning: generateStructuralReasoning("nailing", {
        fastenerSize: nailingPattern.fastenerSize,
        fastenerType: nailingPattern.fastenerType,
        edgeSpacing: nailingPattern.edgeSpacing,
        fieldSpacing: nailingPattern.fieldSpacing,
        application: application
      }),
      assumptions: [
        `Nailing pattern meets building code requirements for ${application}`,
        `${nailingPattern.fastenerType} assumed for structural adequacy`
      ]
    };
  }

  /**
   * Infer species based on regional defaults
   */
  private inferSpecies(item: TakeoffLineItem): StructuralInference {
    return {
      field: "material.species",
      originalValue: item.material.species,
      inferredValue: REGIONAL_DEFAULTS.species.default,
      confidence: REGIONAL_DEFAULTS.species.confidence,
      reasoning: generateStructuralReasoning("species", {
        species: REGIONAL_DEFAULTS.species.default
      }),
      assumptions: [
        `${REGIONAL_DEFAULTS.species.default} species assumed based on regional availability`,
        `Alternative species: ${REGIONAL_DEFAULTS.species.alternatives.join(", ")}`
      ]
    };
  }

  /**
   * Infer grade based on structural requirements
   */
  private inferGrade(item: TakeoffLineItem): StructuralInference {
    const scope = item.context.scope.toLowerCase();
    const isStructural = scope.includes("header") || scope.includes("beam") || 
                        scope.includes("joist") || scope.includes("rafter");
    
    const grade = isStructural ? REGIONAL_DEFAULTS.grade.structural : REGIONAL_DEFAULTS.grade.nonStructural;

    return {
      field: "material.grade",
      originalValue: item.material.grade,
      inferredValue: grade,
      confidence: REGIONAL_DEFAULTS.grade.confidence,
      reasoning: generateStructuralReasoning("grade", { grade }),
      assumptions: [
        `${grade} grade assumed for ${isStructural ? 'structural' : 'non-structural'} application`,
        `Grade provides adequate strength properties for typical residential loads`
      ]
    };
  }

  /**
   * Infer missing structural elements that should be present
   */
  private async inferMissingStructuralElements(
    lineItems: TakeoffLineItem[],
    _context: EnrichmentContext
  ): Promise<StructuralInference[]> {
    const inferences: StructuralInference[] = [];
    
    // Check for missing headers where openings exist
    const openings = lineItems.filter(item => 
      item.context.scope.toLowerCase().includes("opening") ||
      item.context.scope.toLowerCase().includes("door") ||
      item.context.scope.toLowerCase().includes("window")
    );

    const headers = lineItems.filter(item => 
      item.context.scope.toLowerCase().includes("header")
    );

    if (openings.length > 0 && headers.length === 0) {
      inferences.push({
        field: "missing_headers",
        originalValue: null,
        inferredValue: "Headers required for openings",
        confidence: 0.85,
        reasoning: "Headers are structurally required above openings to carry loads. Standard header sizes can be determined from opening widths.",
        assumptions: [
          `${openings.length} openings detected requiring headers`,
          "Header sizes can be calculated from opening spans and load requirements"
        ]
      });
    }

    return inferences;
  }

  /**
   * Helper methods for extracting information from line items
   */
  private extractOpeningWidth(item: TakeoffLineItem): number | null {
    // Try to extract from material size
    if (item.material.size) {
      const match = item.material.size.match(/(\d+)['"]?\s*(?:x|\*|×)/);
      if (match) return parseInt(match[1]);
    }

    // Try to extract from context or assumptions
    const widthAssumption = item.assumptions.find(a => 
      a.toLowerCase().includes("width") || a.toLowerCase().includes("span")
    );
    if (widthAssumption) {
      const match = widthAssumption.match(/(\d+)['"]?/);
      if (match) return parseInt(match[1]);
    }

    // Default assumption for typical openings
    const scope = item.context.scope.toLowerCase();
    if (scope.includes("door")) return 36; // Standard door width
    if (scope.includes("window")) return 48; // Typical window width
    
    return null;
  }

  private inferMemberSize(item: TakeoffLineItem): string | null {
    if (item.material.size) return item.material.size;
    
    const scope = item.context.scope.toLowerCase();
    if (scope.includes("joist")) return "2x10"; // Common joist size
    if (scope.includes("stud")) return "2x4"; // Standard stud size
    if (scope.includes("post")) return "4x4"; // Common post size
    
    return null;
  }

  private inferConnectorApplication(item: TakeoffLineItem): string | null {
    const scope = item.context.scope.toLowerCase();
    if (scope.includes("joist") || scope.includes("hanger")) return "joist_hanger";
    if (scope.includes("post") || scope.includes("anchor")) return "post_anchor";
    if (scope.includes("hold") || scope.includes("down")) return "hold_down";
    if (scope.includes("strap") || scope.includes("tie")) return "strap";
    
    return null;
  }

  private inferSheathingMaterial(item: TakeoffLineItem): string | null {
    const spec = item.material.spec.toLowerCase();
    if (spec.includes("osb")) return "OSB";
    if (spec.includes("plywood")) return "Plywood";
    if (spec.includes("sheathing")) return "OSB"; // Default assumption
    
    return null;
  }

  private inferNailingApplication(item: TakeoffLineItem): string | null {
    const scope = item.context.scope.toLowerCase();
    if (scope.includes("wall") && scope.includes("sheathing")) return "wall_sheathing";
    if (scope.includes("roof") && scope.includes("sheathing")) return "roof_sheathing";
    if (scope.includes("floor") && scope.includes("sheathing")) return "floor_sheathing";
    if (scope.includes("shear")) return "shear_wall";
    if (scope.includes("stud")) return "stud_to_plate";
    if (scope.includes("joist")) return "joist_to_sill";
    
    return null;
  }

  /**
   * Calculate overall confidence based on inferences and available data
   */
  private calculateConfidence(inferences: StructuralInference[], hasStructuralPlans: boolean): number {
    if (inferences.length === 0) return hasStructuralPlans ? 0.9 : 0.6;

    const avgConfidence = inferences.reduce((sum, inf) => sum + inf.confidence, 0) / inferences.length;
    
    // Boost confidence if we have some structural plans
    const structuralBoost = hasStructuralPlans ? 0.1 : 0;
    
    // Penalize if we're making many assumptions
    const assumptionPenalty = Math.min(inferences.length * 0.02, 0.2);
    
    return Math.max(0.4, Math.min(0.95, avgConfidence + structuralBoost - assumptionPenalty));
  }
}