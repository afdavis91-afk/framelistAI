/**
 * Structural Assumptions Database
 * Knowledge base of standard structural assumptions for when S-series plans are missing
 */

export interface HeaderAssumption {
  minSpan: number; // inches
  maxSpan: number; // inches
  size: string;
  plies: number;
  species: string;
  grade: string;
  confidence: number;
}

export interface ConnectorAssumption {
  memberSize: string;
  application: string;
  connectorType: string;
  model: string;
  loadRating: number; // lbs
  confidence: number;
}

export interface NailingPattern {
  material: string;
  application: string;
  fastenerType: string;
  fastenerSize: string;
  edgeSpacing: string;
  fieldSpacing: string;
  confidence: number;
}

// Header size lookup based on opening width and typical residential loads
export const HEADER_ASSUMPTIONS: HeaderAssumption[] = [
  // Single-ply headers for smaller openings
  { minSpan: 0, maxSpan: 36, size: "2x6", plies: 1, species: "SPF", grade: "No.2", confidence: 0.85 },
  { minSpan: 36, maxSpan: 48, size: "2x8", plies: 1, species: "SPF", grade: "No.2", confidence: 0.80 },
  { minSpan: 48, maxSpan: 60, size: "2x10", plies: 1, species: "SPF", grade: "No.2", confidence: 0.75 },
  
  // Double-ply headers for larger openings
  { minSpan: 60, maxSpan: 72, size: "2x8", plies: 2, species: "SPF", grade: "No.2", confidence: 0.80 },
  { minSpan: 72, maxSpan: 96, size: "2x10", plies: 2, species: "SPF", grade: "No.2", confidence: 0.75 },
  { minSpan: 96, maxSpan: 120, size: "2x12", plies: 2, species: "SPF", grade: "No.2", confidence: 0.70 },
  
  // Triple-ply headers for very large openings
  { minSpan: 120, maxSpan: 144, size: "2x10", plies: 3, species: "SPF", grade: "No.2", confidence: 0.65 },
  { minSpan: 144, maxSpan: 168, size: "2x12", plies: 3, species: "SPF", grade: "No.2", confidence: 0.60 },
  
  // Engineered lumber for spans over 14 feet
  { minSpan: 168, maxSpan: 240, size: "LVL", plies: 1, species: "Engineered", grade: "2.0E", confidence: 0.55 },
];

// Standard connector assumptions based on framing configuration
export const CONNECTOR_ASSUMPTIONS: ConnectorAssumption[] = [
  // Joist hangers
  { memberSize: "2x6", application: "joist_hanger", connectorType: "Joist Hanger", model: "U26", loadRating: 1755, confidence: 0.90 },
  { memberSize: "2x8", application: "joist_hanger", connectorType: "Joist Hanger", model: "U28", loadRating: 1755, confidence: 0.90 },
  { memberSize: "2x10", application: "joist_hanger", connectorType: "Joist Hanger", model: "U210", loadRating: 1755, confidence: 0.90 },
  { memberSize: "2x12", application: "joist_hanger", connectorType: "Joist Hanger", model: "U212", loadRating: 1755, confidence: 0.90 },
  
  // Post anchors
  { memberSize: "4x4", application: "post_anchor", connectorType: "Post Anchor", model: "ABA44", loadRating: 3150, confidence: 0.85 },
  { memberSize: "6x6", application: "post_anchor", connectorType: "Post Anchor", model: "ABA66", loadRating: 4200, confidence: 0.85 },
  
  // Hold-downs for shear walls
  { memberSize: "2x4", application: "hold_down", connectorType: "Hold-Down", model: "HDU2", loadRating: 3500, confidence: 0.80 },
  { memberSize: "2x6", application: "hold_down", connectorType: "Hold-Down", model: "HDU4", loadRating: 5500, confidence: 0.80 },
  
  // Straps and ties
  { memberSize: "2x4", application: "strap", connectorType: "Strap Tie", model: "ST2212", loadRating: 1200, confidence: 0.85 },
  { memberSize: "2x6", application: "strap", connectorType: "Strap Tie", model: "ST2214", loadRating: 1400, confidence: 0.85 },
];

// Code-compliant nailing patterns for different applications
export const NAILING_PATTERNS: NailingPattern[] = [
  // Sheathing nailing patterns
  { 
    material: "OSB", 
    application: "wall_sheathing", 
    fastenerType: "Common Nail", 
    fastenerSize: "8d", 
    edgeSpacing: "6\" o.c.", 
    fieldSpacing: "12\" o.c.", 
    confidence: 0.95 
  },
  { 
    material: "Plywood", 
    application: "wall_sheathing", 
    fastenerType: "Common Nail", 
    fastenerSize: "8d", 
    edgeSpacing: "6\" o.c.", 
    fieldSpacing: "12\" o.c.", 
    confidence: 0.95 
  },
  { 
    material: "OSB", 
    application: "roof_sheathing", 
    fastenerType: "Common Nail", 
    fastenerSize: "8d", 
    edgeSpacing: "6\" o.c.", 
    fieldSpacing: "12\" o.c.", 
    confidence: 0.95 
  },
  { 
    material: "Plywood", 
    application: "floor_sheathing", 
    fastenerType: "Ring Shank Nail", 
    fastenerSize: "10d", 
    edgeSpacing: "6\" o.c.", 
    fieldSpacing: "10\" o.c.", 
    confidence: 0.95 
  },
  
  // Framing nailing patterns
  { 
    material: "Lumber", 
    application: "stud_to_plate", 
    fastenerType: "Common Nail", 
    fastenerSize: "16d", 
    edgeSpacing: "2 nails", 
    fieldSpacing: "end nail", 
    confidence: 0.90 
  },
  { 
    material: "Lumber", 
    application: "joist_to_sill", 
    fastenerType: "Common Nail", 
    fastenerSize: "16d", 
    edgeSpacing: "3 nails", 
    fieldSpacing: "toenail", 
    confidence: 0.90 
  },
  
  // Shear wall nailing (higher density)
  { 
    material: "OSB", 
    application: "shear_wall", 
    fastenerType: "Common Nail", 
    fastenerSize: "8d", 
    edgeSpacing: "4\" o.c.", 
    fieldSpacing: "6\" o.c.", 
    confidence: 0.85 
  },
  { 
    material: "Plywood", 
    application: "shear_wall", 
    fastenerType: "Common Nail", 
    fastenerSize: "8d", 
    edgeSpacing: "4\" o.c.", 
    fieldSpacing: "6\" o.c.", 
    confidence: 0.85 
  },
];

// Regional defaults for species and grades
export const REGIONAL_DEFAULTS = {
  species: {
    default: "SPF",
    alternatives: ["Douglas Fir", "Southern Pine", "Hem-Fir"],
    confidence: 0.80
  },
  grade: {
    structural: "No.2",
    nonStructural: "Stud",
    confidence: 0.85
  },
  fasteners: {
    galvanized: true,
    reason: "Standard for exterior and moisture-prone applications",
    confidence: 0.90
  }
};

// Building code minimums for various applications
export const CODE_MINIMUMS = {
  studSpacing: {
    standard: 16, // inches o.c.
    maximum: 24, // inches o.c.
    confidence: 0.95
  },
  plateHeight: {
    minimum: 96, // inches (8 feet)
    standard: 108, // inches (9 feet)
    confidence: 0.90
  },
  joistSpacing: {
    standard: 16, // inches o.c.
    alternatives: [12, 19.2, 24],
    confidence: 0.85
  },
  sheathingThickness: {
    wall: 0.5, // inches (1/2")
    roof: 0.625, // inches (5/8")
    floor: 0.75, // inches (3/4")
    confidence: 0.90
  }
};

/**
 * Get header assumption based on opening width
 */
export function getHeaderAssumption(openingWidth: number): HeaderAssumption | null {
  return HEADER_ASSUMPTIONS.find(h => 
    openingWidth >= h.minSpan && openingWidth < h.maxSpan
  ) || null;
}

/**
 * Get connector assumption based on member size and application
 */
export function getConnectorAssumption(memberSize: string, application: string): ConnectorAssumption | null {
  return CONNECTOR_ASSUMPTIONS.find(c => 
    c.memberSize === memberSize && c.application === application
  ) || null;
}

/**
 * Get nailing pattern based on material and application
 */
export function getNailingPattern(material: string, application: string): NailingPattern | null {
  return NAILING_PATTERNS.find(p => 
    p.material.toLowerCase().includes(material.toLowerCase()) && 
    p.application === application
  ) || null;
}

/**
 * Generate reasoning explanation for structural assumption
 */
export function generateStructuralReasoning(assumptionType: string, details: any): string {
  switch (assumptionType) {
    case "header":
      return `Header size ${details.size} assumed for ${details.span}" opening based on typical residential load requirements and span tables. ${details.plies > 1 ? `${details.plies}-ply configuration` : 'Single-ply'} provides adequate capacity for standard loading.`;
    
    case "connector":
      return `${details.connectorType} ${details.model} assumed for ${details.memberSize} ${details.application} based on standard construction practices and typical load requirements (${details.loadRating} lbs capacity).`;
    
    case "nailing":
      return `${details.fastenerSize} ${details.fastenerType} nailing pattern assumed: ${details.edgeSpacing} edges, ${details.fieldSpacing} field spacing. Pattern meets building code requirements for ${details.application}.`;
    
    case "species":
      return `${details.species} species assumed based on regional availability and cost-effectiveness for structural framing applications.`;
    
    case "grade":
      return `${details.grade} grade assumed as standard structural grade for framing lumber, providing adequate strength properties for typical residential loads.`;
    
    default:
      return `Standard assumption applied based on building code minimums and typical construction practices.`;
  }
}