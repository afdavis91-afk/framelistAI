# Vision Enrichment Module

The Vision Enrichment Module integrates AI vision analysis into the enrichment pipeline to enhance takeoff line items with visual evidence from construction drawings.

## Overview

This module uses OpenAI's GPT-4 Vision model to analyze specific areas of construction drawings and extract structured information that can enhance the confidence and accuracy of takeoff items.

## Features

- **Task-Based Analysis**: Focuses on specific drawing elements (legends, schedules, callouts, plan tiles)
- **Smart Prioritization**: Automatically prioritizes high-impact vision tasks
- **Concurrency Control**: Processes multiple vision tasks efficiently with configurable concurrency
- **Caching**: Intelligent caching to avoid duplicate API calls
- **Settings Integration**: Can be enabled/disabled via user settings
- **Evidence Chain**: Creates comprehensive audit trails linking vision results to line items

## Architecture

### Core Components

1. **VisionClient** (`VisionClient.ts`)
   - Handles OpenAI API calls with retry logic
   - Implements caching and error handling
   - Supports structured JSON output

2. **Task Management** (`tasks.ts`)
   - Defines vision task types and priorities
   - Creates task-specific analysis contexts
   - Implements smart task filtering

3. **Prompt Building** (`buildUserPrompt.ts`)
   - Generates task-specific prompts and JSON schemas
   - Ensures consistent output formatting
   - Maintains construction domain expertise

4. **System Policy** (`buildSystemPolicy.ts`)
   - Defines AI behavior and output constraints
   - Incorporates your existing output policy
   - Ensures construction-specific analysis

5. **VisionEnrichmentModule** (`VisionEnrichmentModule.ts`)
   - Orchestrates the vision analysis pipeline
   - Integrates with existing enrichment modules
   - Applies vision results to line items

## Task Types

### 1. Legend Analysis (`LEGEND`)
- **Purpose**: Extract wall type specifications from legends
- **Input**: Wall type legend areas
- **Output**: Structured wall type data (stud size, spacing, sheathing, etc.)
- **Priority**: High (affects many items)

### 2. Schedule Analysis (`SCHEDULE`)
- **Purpose**: Parse header/beam and door/window schedules
- **Input**: Schedule table areas
- **Output**: Structured schedule data with marks, sizes, materials
- **Priority**: High (quantitative data)

### 3. Callout Analysis (`CALLOUT`)
- **Purpose**: Resolve cross-references and detail notes
- **Input**: Callout note areas
- **Output**: Structured reference data and construction notes
- **Priority**: Medium (reference resolution)

### 4. Plan Tile Analysis (`PLAN_TILE`)
- **Purpose**: Analyze specific plan areas for structural elements
- **Input**: Focused plan areas
- **Output**: Geometric entities and construction details
- **Priority**: Low (detailed analysis)

## Usage

### Basic Integration

The module is automatically integrated into the enrichment pipeline:

```typescript
// In EnrichmentService constructor
this.modules = [
  // ... other modules
  new VisionEnrichmentModule(), // Automatically processes vision tasks
  // ... drawing modules
];
```

### Settings Control

Users can enable/disable vision analysis via settings:

```typescript
// In SettingsScreen
<SwitchRow
  title="Enable Vision Analysis"
  description="Use AI vision to analyze schedules, legends, and callouts"
  value={enableVisionAnalysis}
  onValueChange={setEnableVisionAnalysis}
/>
```

### Task Identification

The module automatically identifies vision opportunities:

```typescript
// Automatically detects when items need vision analysis
const visionTasks = this.identifyVisionTasks(lineItems, context);

// Creates tasks based on:
// - Wall types in scope
// - Schedule references
// - Callout notes
// - Plan complexity
```

## Configuration

### Environment Variables

```bash
# OpenAI API configuration
OPENAI_API_KEY=your_api_key_here
OPENAI_VISION_MODEL=gpt-4o  # or gpt-5 when available
```

### Concurrency Settings

```typescript
// In VisionEnrichmentModule
const concurrency = 3; // Process 3 tasks simultaneously
const maxTasks = 5;    // Limit to top 5 priority tasks
```

### Caching

```typescript
// Automatic caching based on:
// - Image content hash
// - Task type
// - Model version
// - Prompt content
```

## Output Integration

### Evidence References

Vision results are stored as evidence references:

```typescript
{
  documentId: "A1.01",
  pageNumber: 1,
  coordinates: [0.8, 0.1, 0.15, 0.3],
  description: "Vision analysis: LEGEND with 80% confidence"
}
```

### Enrichment Data

Results enhance line items with:

```typescript
enrichmentData: {
  enrichmentFlags: [{
    type: "EVIDENCE_ENHANCED",
    message: "Enhanced by vision analysis: LEGEND with 80% confidence",
    severity: "low",
    sheets: ["A1.01"],
    moduleSource: "VisionEnrichment",
    resolved: true
  }],
  confidenceBoost: 0.08 // 8% confidence increase
}
```

### UI Display

Vision evidence appears in line item cards:

```typescript
{/* Vision Analysis Evidence */}
{item.evidenceRefs.filter(ref => ref.description.includes("Vision analysis")).map((ref, idx) => (
  <View key={`vision-${idx}`} className="mb-2 bg-blue-50 p-2 rounded">
    <Text className="text-xs font-medium text-blue-700 mb-1">Vision Analysis</Text>
    <Text className="text-xs text-blue-600">{ref.description}</Text>
    {/* View Source button */}
  </View>
))}
```

## Performance Considerations

### API Cost Management

- **Task Prioritization**: Only processes high-impact tasks
- **Confidence Thresholds**: Skips low-confidence opportunities
- **Caching**: Avoids duplicate analysis
- **Concurrency Limits**: Prevents API rate limiting

### Processing Efficiency

- **Batch Processing**: Groups related tasks
- **Progress Tracking**: Real-time feedback during processing
- **Error Handling**: Graceful degradation on failures
- **Memory Management**: Efficient image handling

## Testing

### Unit Tests

```bash
# Run vision module tests
npm test -- VisionEnrichmentModule.test.ts
```

### Test Coverage

- Task identification logic
- Vision result application
- Settings integration
- Error handling scenarios

## Future Enhancements

### GPT-5 Integration

```typescript
// When GPT-5 Vision is available
model: process.env.OPENAI_VISION_MODEL ?? "gpt-5-vision-preview"
```

### Advanced Cropping

```typescript
// Replace mock crop areas with intelligent detection
private estimateLegendCropArea(): BoundingBox {
  // Use computer vision to detect legend boundaries
  return this.detectLegendBoundaries();
}
```

### Multi-Modal Analysis

```typescript
// Combine text and vision analysis
const combinedResult = await Promise.all([
  this.analyzeText(item),
  this.analyzeVision(item)
]);
```

## Troubleshooting

### Common Issues

1. **API Rate Limits**: Reduce concurrency or implement exponential backoff
2. **Memory Issues**: Optimize image processing and caching
3. **Cost Concerns**: Adjust confidence thresholds and task limits
4. **Performance**: Monitor task processing times and optimize bottlenecks

### Debug Mode

```typescript
// Enable detailed logging
console.log('[VisionEnrichment] Task identified:', task);
console.log('[VisionEnrichment] API response:', result);
```

## Contributing

When adding new vision task types:

1. Define the task interface in `tasks.ts`
2. Create prompt builders in `buildUserPrompt.ts`
3. Add task-specific logic in `VisionEnrichmentModule.ts`
4. Update tests and documentation
5. Consider performance and cost implications
