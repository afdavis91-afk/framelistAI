import { VisionEnrichmentModule } from '../VisionEnrichmentModule';
import { TakeoffLineItem, EnrichmentContext } from '../../../types/construction';

// Mock the vision client
jest.mock('../VisionClient', () => ({
  visionClient: {
    runVision: jest.fn(),
  },
}));

describe('VisionEnrichmentModule', () => {
  let module: VisionEnrichmentModule;
  let mockContext: EnrichmentContext;
  let mockLineItems: TakeoffLineItem[];

  beforeEach(() => {
    module = new VisionEnrichmentModule();
    
    mockContext = {
      projectDocuments: [],
      baselineAnalysis: {
        lineItems: [],
        flags: [],
        confidence: 0.8,
        projectInfo: {
          name: 'Test Project',
          address: 'Test Address',
          levels: [],
          buildingCode: '',
          seismicCategory: '',
          windCategory: '',
        },
        joistSystems: [],
        roofFraming: [],
        sheathingSystems: [],
      },
      constructionStandards: {
        studSpacingDefault: 16,
        cornerStudCount: 3,
        tIntersectionStudCount: 2,
        headerBearing: 1.5,
        wasteFactors: {
          studsPct: 10,
          platesPct: 5,
          sheathingPct: 10,
          blockingPct: 15,
          fastenersPct: 5,
        },
      },
    };

    mockLineItems = [
      {
        itemId: 'item_1',
        uom: 'LF',
        qty: 100,
        material: {
          spec: 'Douglas Fir-Larch',
          grade: 'Construction Grade',
          size: '2x6',
        },
        context: {
          scope: 'Wall Framing',
          wallType: 'W1',
          level: 'First Floor',
          sheetRef: 'A1.01',
          viewRef: 'Floor Plan',
          bbox: [0, 0, 100, 100],
          sourceNotes: [],
        },
        assumptions: [],
        confidence: 0.7,
        evidenceRefs: [],
      },
    ];
  });

  describe('process', () => {
    it('should return early if vision analysis is disabled', async () => {
      // Mock settings store to disable vision analysis
      jest.doMock('../../../state/settingsStore', () => ({
        useSettingsStore: {
          getState: () => ({ enableVisionAnalysis: false }),
        },
      }));

      const result = await module.process(mockLineItems, mockContext);
      
      expect(result.confidence).toBe(0);
      expect(result.enrichedLineItems).toEqual(mockLineItems);
    });

    it('should identify vision tasks for wall types', async () => {
      // Mock settings store to enable vision analysis
      jest.doMock('../../../state/settingsStore', () => ({
        useSettingsStore: {
          getState: () => ({ enableVisionAnalysis: true }),
        },
      }));

      const result = await module.process(mockLineItems, mockContext);
      
      // Should process items and potentially enhance them
      expect(result.enrichedLineItems.length).toBeGreaterThan(0);
    });
  });

  describe('task identification', () => {
    it('should create legend tasks for wall types', () => {
      const tasks = (module as any).identifyVisionTasks(mockLineItems, mockContext);
      
      // Should identify at least one task for wall types
      const legendTasks = tasks.filter((t: any) => t.type === 'LEGEND');
      expect(legendTasks.length).toBeGreaterThan(0);
    });

    it('should prioritize high-impact tasks', () => {
      const tasks = (module as any).identifyVisionTasks(mockLineItems, mockContext);
      
      // Should sort by priority
      expect(tasks[0].priority).toBeGreaterThanOrEqual(tasks[tasks.length - 1]?.priority || 0);
    });
  });

  describe('vision result application', () => {
    it('should enhance items with vision results', () => {
      const mockResult = {
        task: { type: 'LEGEND', sheetId: 'A1.01' },
        result: { confidence: 0.8 },
        confidence: 0.8,
        evidence: {
          documentId: 'A1.01',
          pageNumber: 1,
          coordinates: [0, 0, 0, 0],
          description: 'Vision analysis: LEGEND with 80% confidence',
        },
      };

      const enhanced = (module as any).applyVisionResult(mockResult, mockLineItems);
      
      expect(enhanced).toBe(true);
    });
  });
});
