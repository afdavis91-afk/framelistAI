export interface TaskPrompt {
  text: string;
  schema: object;
}

export function promptForHeaderSchedule(sheetId: string): TaskPrompt {
  const schema = {
    type: "object",
    properties: {
      sheet: { type: "string" },
      scheduleTitle: { type: "string" },
      headers: {
        type: "array",
        items: {
          type: "object",
          properties: {
            id: { type: "string" },
            size: { type: "string" },   // e.g., "(2) 2x10 DF-L"
            ply: { type: "number" },
            notes: { type: "string" }
          },
          required: ["id", "size"]
        }
      },
      confidence: { type: "number" }
    },
    required: ["sheet", "headers", "confidence"],
    additionalProperties: false
  };

  const text = [
    `Task: Extract the HEADER/BEAM schedule table from sheet ${sheetId}.`,
    `Return JSON that conforms exactly to the provided schema.`,
    `If the image is not a header schedule, return headers: [] and confidence <= 0.4 and include a reason in notes.`,
    `Use the model's own reading of the image; do not rely on external context.`,
    `Extract all visible header/beam entries with their marks, sizes, and specifications.`
  ].join("\n");

  return { text, schema };
}

export function promptForWallLegend(sheetId: string): TaskPrompt {
  const schema = {
    type: "object",
    properties: {
      sheet: { type: "string" },
      legend: {
        type: "array",
        items: {
          type: "object",
          properties: {
            tag: { type: "string" },
            stud: { type: "string" },         // "2x6"
            spacing_in: { type: "number" },   // 16
            sheathing: { type: "string" },    // "7/16\" OSB"
            gyp: { type: "string" },
            plate_ht_ft: { type: "number" },
            notes: { type: "string" }
          },
          required: ["tag", "stud"]
        }
      },
      confidence: { type: "number" }
    },
    required: ["sheet", "legend", "confidence"],
    additionalProperties: false
  };

  const text = [
    `Task: Extract the WALL TYPE LEGEND entries from sheet ${sheetId}.`,
    `Normalize fields as in the schema. If spacing appears as "16\" o.c.", set spacing_in = 16.`,
    `If values are not present, omit them or leave empty string; do not invent.`,
    `Focus on structural wall types with stud sizes, spacing, and sheathing information.`
  ].join("\n");

  return { text, schema };
}

export function promptForDoorWindowSchedule(sheetId: string): TaskPrompt {
  const schema = {
    type: "object",
    properties: {
      sheet: { type: "string" },
      scheduleTitle: { type: "string" },
      openings: {
        type: "array",
        items: {
          type: "object",
          properties: {
            mark: { type: "string" },
            type: { type: "string" },         // "Door" or "Window"
            size: { type: "string" },         // "3-0 x 6-8"
            material: { type: "string" },
            frame: { type: "string" },
            hardware: { type: "string" },
            notes: { type: "string" }
          },
          required: ["mark", "type", "size"]
        }
      },
      confidence: { type: "number" }
    },
    required: ["sheet", "openings", "confidence"],
    additionalProperties: false
  };

  const text = [
    `Task: Extract the DOOR/WINDOW schedule table from sheet ${sheetId}.`,
    `Return JSON that conforms exactly to the provided schema.`,
    `If the image is not a door/window schedule, return openings: [] and confidence <= 0.4.`,
    `Extract all visible door and window entries with their marks, types, sizes, and specifications.`
  ].join("\n");

  return { text, schema };
}

export function promptForCalloutNote(sheetId: string): TaskPrompt {
  const schema = {
    type: "object",
    properties: {
      sheet: { type: "string" },
      callout: { type: "string" },
      target: {
        type: "object",
        properties: {
          detail: { type: "string" },
          sheet: { type: "string" }
        }
      },
      notes: { type: "string" },
      connectors: {
        type: "array",
        items: { type: "string" }
      },
      nailing: {
        type: "object",
        properties: {
          edge_in: { type: "number" },
          field_in: { type: "number" }
        }
      },
      confidence: { type: "number" }
    },
    required: ["sheet", "callout", "confidence"],
    additionalProperties: false
  };

  const text = [
    `Task: Extract the CALLOUT NOTE information from sheet ${sheetId}.`,
    `Look for construction details, notes, or callouts that reference other sheets or details.`,
    `Extract any connector specifications, nailing patterns, or construction notes.`,
    `If no callout information is found, return minimal data with confidence <= 0.4.`
  ].join("\n");

  return { text, schema };
}

export function promptForPlanTile(sheetId: string, focusArea: string): TaskPrompt {
  const schema = {
    type: "object",
    properties: {
      sheet: { type: "string" },
      focusArea: { type: "string" },
      elements: {
        type: "array",
        items: {
          type: "object",
          properties: {
            type: { type: "string" },         // "wall", "opening", "dimension", "symbol"
            location: { type: "string" },     // relative position description
            size: { type: "string" },         // dimensions if visible
            notes: { type: "string" }
          },
          required: ["type", "location"]
        }
      },
      confidence: { type: "number" }
    },
    required: ["sheet", "focusArea", "elements", "confidence"],
    additionalProperties: false
  };

  const text = [
    `Task: Analyze the PLAN TILE from sheet ${sheetId}, focusing on ${focusArea}.`,
    `Identify structural elements, openings, dimensions, and construction symbols.`,
    `Extract quantitative information where possible (lengths, counts, spacing).`,
    `Focus on elements relevant to framing and construction.`
  ].join("\n");

  return { text, schema };
}

export function promptForJoistSchedule(sheetId: string): TaskPrompt {
  const schema = {
    type: "object",
    properties: {
      sheet: { type: "string" },
      scheduleTitle: { type: "string" },
      joists: {
        type: "array",
        items: {
          type: "object",
          properties: {
            mark: { type: "string" },
            type: { type: "string" },         // "floor", "ceiling", "roof"
            size: { type: "string" },         // "2x10", "I-joist 11-7/8", "LVL 1.75x11.25"
            spacing: { type: "number" },      // 16, 19.2, 24
            span: { type: "number" },         // span in feet
            species: { type: "string" },      // "SPF", "DF-L", "SYP", "engineered"
            grade: { type: "string" },        // "No.2", "No.1", "select", "2.0E"
            treatment: { type: "string" },    // "none", "pressure_treated", "fire_retardant"
            engineeredType: { type: "string" }, // "I-joist", "LVL", "LSL", "PSL", "solid_sawn"
            hangerType: { type: "string" },   // "standard", "heavy_duty", "skewed"
            hangerSize: { type: "string" },   // "2x10", "custom"
            blockingSpacing: { type: "number" }, // 48, 96
            bridgingType: { type: "string" },  // "solid", "cross", "metal"
            liveLoad: { type: "number" },     // 40, 50, 60 psf
            deadLoad: { type: "number" },     // 10, 15, 20 psf
            notes: { type: "string" }
          },
          required: ["mark", "size"]
        }
      },
      confidence: { type: "number" }
    },
    required: ["sheet", "joists", "confidence"],
    additionalProperties: false
  };

  const text = [
    `Task: Extract the JOIST/FLOOR FRAMING schedule table from sheet ${sheetId}.`,
    `Return JSON that conforms exactly to the provided schema.`,
    `If the image is not a joist schedule, return joists: [] and confidence <= 0.4.`,
    `Extract all visible joist entries with their marks, sizes, spacing, spans, and specifications.`,
    `Look for engineered lumber specifications (I-joists, LVL, LSL, PSL).`,
    `Include hanger types, blocking requirements, and load specifications where visible.`
  ].join("\n");

  return { text, schema };
}

export function promptForRafterSchedule(sheetId: string): TaskPrompt {
  const schema = {
    type: "object",
    properties: {
      sheet: { type: "string" },
      scheduleTitle: { type: "string" },
      rafters: {
        type: "array",
        items: {
          type: "object",
          properties: {
            mark: { type: "string" },
            type: { type: "string" },         // "common", "hip", "valley", "jack", "ridge"
            size: { type: "string" },         // "2x8", "2x10", "I-joist", "LVL"
            spacing: { type: "number" },      // 16, 19.2, 24
            span: { type: "number" },         // span in feet
            species: { type: "string" },      // "SPF", "DF-L", "SYP", "engineered"
            grade: { type: "string" },        // "No.2", "No.1", "select", "2.0E"
            treatment: { type: "string" },    // "none", "pressure_treated", "fire_retardant"
            engineeredType: { type: "string" }, // "I-joist", "LVL", "LSL", "PSL", "solid_sawn"
            pitch: { type: "number" },        // 4, 6, 8, 10, 12 (in 12)
            overhang: { type: "number" },     // overhang in inches
            ridgeBoard: { type: "string" },   // "2x10", "2x12", "LVL"
            collarTies: { type: "string" },   // "2x6", "2x8", "none"
            rafterTies: { type: "string" },   // "2x4", "2x6", "none"
            hangerType: { type: "string" },   // "standard", "heavy_duty", "skewed"
            bearingLength: { type: "number" }, // bearing length in inches
            snowLoad: { type: "number" },     // 20, 30, 40, 50 psf
            windLoad: { type: "number" },     // 15, 20, 25, 30 psf
            notes: { type: "string" }
          },
          required: ["mark", "size"]
        }
      },
      confidence: { type: "number" }
    },
    required: ["sheet", "rafters", "confidence"],
    additionalProperties: false
  };

  const text = [
    `Task: Extract the RAFTER/ROOF FRAMING schedule table from sheet ${sheetId}.`,
    `Return JSON that conforms exactly to the provided schema.`,
    `If the image is not a rafter schedule, return rafters: [] and confidence <= 0.4.`,
    `Extract all visible rafter entries with their marks, sizes, spacing, spans, and specifications.`,
    `Look for pitch information, overhang details, and ridge board specifications.`,
    `Include collar ties, rafter ties, and load specifications where visible.`
  ].join("\n");

  return { text, schema };
}

export function promptForBeamSchedule(sheetId: string): TaskPrompt {
  const schema = {
    type: "object",
    properties: {
      sheet: { type: "string" },
      scheduleTitle: { type: "string" },
      beams: {
        type: "array",
        items: {
          type: "object",
          properties: {
            mark: { type: "string" },
            type: { type: "string" },         // "header", "girder", "ridge", "collar", "tie"
            size: { type: "string" },         // "2x12", "3x12", "glulam 5.125x13.5", "LVL 1.75x11.25"
            span: { type: "number" },         // span in feet
            species: { type: "string" },      // "SPF", "DF-L", "SYP", "glulam", "steel"
            grade: { type: "string" },        // "No.2", "No.1", "select", "24F-V4", "A36"
            treatment: { type: "string" },    // "none", "pressure_treated", "fire_retardant"
            engineeredType: { type: "string" }, // "glulam", "LVL", "LSL", "PSL", "solid_sawn", "steel"
            plyCount: { type: "number" },     // 1, 2, 3, 4
            bearingLength: { type: "number" }, // bearing length in inches
            connectionType: { type: "string" }, // "bearing", "hanger", "bolted", "welded"
            hangerType: { type: "string" },   // "standard", "heavy_duty", "custom"
            designLoad: { type: "number" },   // design load in lbs
            deflectionLimit: { type: "string" }, // "L/240", "L/360", "L/480"
            notes: { type: "string" }
          },
          required: ["mark", "size"]
        }
      },
      confidence: { type: "number" }
    },
    required: ["sheet", "beams", "confidence"],
    additionalProperties: false
  };

  const text = [
    `Task: Extract the BEAM/HEADER schedule table from sheet ${sheetId}.`,
    `Return JSON that conforms exactly to the provided schema.`,
    `If the image is not a beam schedule, return beams: [] and confidence <= 0.4.`,
    `Extract all visible beam entries with their marks, sizes, spans, and specifications.`,
    `Look for engineered lumber specifications (glulam, LVL, LSL, PSL).`,
    `Include connection details, load ratings, and deflection limits where visible.`
  ].join("\n");

  return { text, schema };
}

export function promptForFramingPlan(sheetId: string): TaskPrompt {
  const schema = {
    type: "object",
    properties: {
      sheet: { type: "string" },
      planType: { type: "string" },        // "floor_framing", "roof_framing", "ceiling_framing"
      framingElements: {
        type: "array",
        items: {
          type: "object",
          properties: {
            type: { type: "string" },       // "joist", "rafter", "beam", "blocking", "hanger"
            mark: { type: "string" },       // reference mark if visible
            size: { type: "string" },       // member size
            spacing: { type: "number" },    // spacing in inches
            span: { type: "number" },       // span in feet
            direction: { type: "string" },  // "north-south", "east-west", "diagonal"
            quantity: { type: "number" },   // count if determinable
            location: { type: "string" },   // relative position description
            notes: { type: "string" }
          },
          required: ["type", "size"]
        }
      },
      dimensions: {
        type: "array",
        items: {
          type: "object",
          properties: {
            value: { type: "number" },      // dimension value
            units: { type: "string" },      // "feet", "inches"
            description: { type: "string" } // what the dimension refers to
          }
        }
      },
      confidence: { type: "number" }
    },
    required: ["sheet", "planType", "framingElements", "confidence"],
    additionalProperties: false
  };

  const text = [
    `Task: Analyze the FRAMING PLAN from sheet ${sheetId}.`,
    `Return JSON that conforms exactly to the provided schema.`,
    `Identify all structural framing elements: joists, rafters, beams, blocking, hangers.`,
    `Extract member sizes, spacing, spans, and quantities where visible.`,
    `Look for dimension strings and extract key measurements.`,
    `Focus on elements that would appear in a material takeoff.`
  ].join("\n");

  return { text, schema };
}

export function promptForConnectorSchedule(sheetId: string): TaskPrompt {
  const schema = {
    type: "object",
    properties: {
      sheet: { type: "string" },
      scheduleTitle: { type: "string" },
      connectors: {
        type: "array",
        items: {
          type: "object",
          properties: {
            mark: { type: "string" },
            type: { type: "string" },        // "joist_hanger", "beam_hanger", "post_anchor", "strap", "tie"
            size: { type: "string" },        // "2x10", "custom", "4x12"
            material: { type: "string" },    // "galvanized_steel", "stainless_steel", "plain_steel"
            loadRating: { type: "number" },  // load rating in lbs
            memberSize: { type: "string" },  // size of member it connects
            fastenerType: { type: "string" }, // "joist_hanger_nail", "structural_screw", "bolt"
            fastenerQuantity: { type: "number" }, // number of fasteners
            seismicRated: { type: "boolean" }, // seismic rating
            windRated: { type: "boolean" },   // wind rating
            manufacturer: { type: "string" }, // "Simpson", "USP", "MiTek"
            model: { type: "string" },       // specific model number
            quantity: { type: "number" },    // quantity required
            notes: { type: "string" }
          },
          required: ["mark", "type"]
        }
      },
      confidence: { type: "number" }
    },
    required: ["sheet", "connectors", "confidence"],
    additionalProperties: false
  };

  const text = [
    `Task: Extract the CONNECTOR/HANGER schedule table from sheet ${sheetId}.`,
    `Return JSON that conforms exactly to the provided schema.`,
    `If the image is not a connector schedule, return connectors: [] and confidence <= 0.4.`,
    `Extract all visible connector entries with their marks, types, sizes, and specifications.`,
    `Look for load ratings, fastener requirements, and manufacturer information.`,
    `Include seismic and wind ratings where specified.`
  ].join("\n");

  return { text, schema };
}
