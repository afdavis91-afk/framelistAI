import { VisionEnrichmentModule } from '../VisionEnrichmentModule';
import { visionClient } from '../VisionClient';
import { buildSystemPolicy } from '../buildSystemPolicy';
import { promptForWallLegend, promptForHeaderSchedule } from '../buildUserPrompt';

/**
 * Example: How to use the Vision Enrichment Module
 * 
 * This example demonstrates the key components and how they work together
 * to enhance takeoff line items with vision analysis.
 */

// Example 1: Basic Vision Analysis
export async function analyzeWallLegendExample() {
  try {
    // 1. Build the system policy (reuses your existing output policy)
    const systemPolicy = buildSystemPolicy();
    
    // 2. Get task-specific prompt and schema
    const { text, schema } = promptForWallLegend("A1.01");
    
    // 3. Run vision analysis
    const result = await visionClient.runVision({
      system: systemPolicy,
      userText: text,
      imageBase64: "your_base64_image_here", // From your HighResCropper
      jsonSchema: schema,
      temperature: 0,
    });
    
    console.log('Wall legend analysis result:', result);
    
    // 4. Process the result
    if (result.confidence > 0.7) {
      console.log('High confidence result, can be used for enrichment');
      result.legend.forEach((wallType: any) => {
        console.log(`Wall type ${wallType.tag}: ${wallType.stud} @ ${wallType.spacing_in}" o.c.`);
      });
    }
    
  } catch (error) {
    console.error('Vision analysis failed:', error);
  }
}

// Example 2: Header Schedule Analysis
export async function analyzeHeaderScheduleExample() {
  try {
    const systemPolicy = buildSystemPolicy();
    const { text, schema } = promptForHeaderSchedule("S1.01");
    
    const result = await visionClient.runVision({
      system: systemPolicy,
      userText: text,
      imageBase64: "your_schedule_image_here",
      jsonSchema: schema,
      temperature: 0,
    });
    
    console.log('Header schedule analysis result:', result);
    
    // Process schedule entries
    if (result.headers && result.headers.length > 0) {
      result.headers.forEach((header: any) => {
        console.log(`Header ${header.id}: ${header.size} (${header.ply} ply)`);
      });
    }
    
  } catch (error) {
    console.error('Schedule analysis failed:', error);
  }
}

// Example 3: Using the VisionEnrichmentModule
export async function useVisionEnrichmentModuleExample() {
  // The module is automatically integrated into your enrichment pipeline
  // But you can also use it standalone if needed
  
  const visionModule = new VisionEnrichmentModule();
  
  // Mock context and line items
  const mockContext = {
    projectDocuments: [],
    baselineAnalysis: {
      lineItems: [],
      flags: [],
      confidence: 0.8,
      projectInfo: {
        name: 'Example Project',
        address: '123 Main St',
        levels: [],
        buildingCode: '',
        seismicCategory: '',
        windCategory: '',
      },
      joistSystems: [],
      roofFraming: [],
      sheathingSystems: [],
    },
    constructionStandards: {
      studSpacingDefault: 16,
      cornerStudCount: 3,
      tIntersectionStudCount: 2,
      headerBearing: 1.5,
      wasteFactors: {
        studsPct: 10,
        platesPct: 5,
        sheathingPct: 10,
        blockingPct: 15,
        fastenersPct: 5,
      },
    },
  };
  
  const mockLineItems = [
    {
      itemId: 'wall_1',
      uom: 'LF',
      qty: 100,
      material: {
        spec: 'Douglas Fir-Larch',
        grade: 'Construction Grade',
        size: '2x6',
      },
      context: {
        scope: 'Wall Framing',
        wallType: 'W1',
        level: 'First Floor',
        sheetRef: 'A1.01',
        viewRef: 'Floor Plan',
        bbox: [0, 0, 100, 100],
        sourceNotes: [],
      },
      assumptions: [],
      confidence: 0.7,
      evidenceRefs: [],
    },
  ];
  
  try {
    // Process line items with vision enrichment
    const result = await visionModule.process(mockLineItems, mockContext);
    
    console.log('Vision enrichment result:', {
      enhancedItems: result.enrichedLineItems.length,
      confidence: result.confidence,
      flags: result.flags.length,
    });
    
    // Check if any items were enhanced
    const enhancedItems = result.enrichedLineItems.filter(item => 
      item.evidenceRefs.some(ref => ref.description.includes('Vision analysis'))
    );
    
    console.log(`${enhancedItems.length} items enhanced with vision analysis`);
    
  } catch (error) {
    console.error('Vision enrichment failed:', error);
  }
}

// Example 4: Custom Vision Task
export async function customVisionTaskExample() {
  // You can create custom vision tasks for specific needs
  
  const customPrompt = {
    text: `Analyze this construction detail for:
    1. Material specifications
    2. Connection details
    3. Dimensions and spacing
    4. Special requirements
    
    Return the information in a structured format.`,
    schema: {
      type: "object",
      properties: {
        materials: {
          type: "array",
          items: {
            type: "object",
            properties: {
              type: { type: "string" },
              spec: { type: "string" },
              size: { type: "string" }
            }
          }
        },
        connections: {
          type: "array",
          items: { type: "string" }
        },
        dimensions: {
          type: "object",
          properties: {
            width: { type: "number" },
            height: { type: "number" },
            spacing: { type: "number" }
          }
        },
        specialRequirements: { type: "string" },
        confidence: { type: "number" }
      },
      required: ["materials", "confidence"]
    }
  };
  
  try {
    const systemPolicy = buildSystemPolicy();
    
    const result = await visionClient.runVision({
      system: systemPolicy,
      userText: customPrompt.text,
      imageBase64: "your_detail_image_here",
      jsonSchema: customPrompt.schema,
      temperature: 0,
    });
    
    console.log('Custom vision task result:', result);
    
  } catch (error) {
    console.error('Custom vision task failed:', error);
  }
}

// Example 5: Batch Processing
export async function batchVisionProcessingExample() {
  // Process multiple images efficiently
  
  const images = [
    { id: 'legend', base64: 'legend_image_base64', type: 'LEGEND' },
    { id: 'schedule', base64: 'schedule_image_base64', type: 'SCHEDULE' },
    { id: 'detail', base64: 'detail_image_base64', type: 'CALLOUT' },
  ];
  
  const systemPolicy = buildSystemPolicy();
  
  try {
    // Process all images concurrently
    const results = await Promise.all(
      images.map(async (image) => {
        let prompt;
        switch (image.type) {
          case 'LEGEND':
            prompt = promptForWallLegend('A1.01');
            break;
          case 'SCHEDULE':
            prompt = promptForHeaderSchedule('A1.01');
            break;
          default:
            prompt = promptForWallLegend('A1.01'); // fallback
        }
        
        return visionClient.runVision({
          system: systemPolicy,
          userText: prompt.text,
          imageBase64: image.base64,
          jsonSchema: prompt.schema,
          temperature: 0,
        });
      })
    );
    
    console.log('Batch processing results:', results);
    
    // Aggregate results
    const allWallTypes = results
      .filter(r => r.legend)
      .flatMap(r => r.legend)
      .map(wt => wt.tag);
    
    const allHeaders = results
      .filter(r => r.headers)
      .flatMap(r => r.headers)
      .map(h => h.id);
    
    console.log('All wall types found:', allWallTypes);
    console.log('All headers found:', allHeaders);
    
  } catch (error) {
    console.error('Batch processing failed:', error);
  }
}

// Export all examples
export const visionExamples = {
  analyzeWallLegend: analyzeWallLegendExample,
  analyzeHeaderSchedule: analyzeHeaderScheduleExample,
  useVisionEnrichmentModule: useVisionEnrichmentModuleExample,
  customVisionTask: customVisionTaskExample,
  batchVisionProcessing: batchVisionProcessingExample,
};
