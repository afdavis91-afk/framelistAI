import { getOpenAIClient } from "../../../api/openai";

export interface VisionArgs {
  system: string;
  userText: string;
  imageBase64: string;
  jsonSchema?: object;
  temperature?: number;
}

export interface VisionResult<T> {
  data: T;
  confidence: number;
  conflicts: string[];
  evidence: {
    documentId: string;
    pageNumber: number;
    coordinates: [number, number, number, number];
    description: string;
  };
}

export class VisionClient {
  private cache = new Map<string, any>();
  private retryCount = 0;
  private readonly maxRetries = 1;

  async runVision<T>(args: VisionArgs): Promise<T> {
    const cacheKey = this.generateCacheKey(args);
    
    // Check cache first
    if (this.cache.has(cacheKey)) {
      return this.cache.get(cacheKey);
    }

    try {
      const result = await this.callVisionAPI(args);
      
      // Cache successful results
      this.cache.set(cacheKey, result);
      this.retryCount = 0; // Reset retry counter
      
      return result;
    } catch (error) {
      if (this.retryCount < this.maxRetries) {
        this.retryCount++;
        // Retry with stricter prompt
        return this.runVisionWithStricterPrompt(args);
      }
      throw error;
    }
  }

  private async callVisionAPI<T>(args: VisionArgs): Promise<T> {
    const { system, userText, imageBase64, jsonSchema, temperature = 0 } = args;
    const client = getOpenAIClient();

    const response = await client.chat.completions.create({
      model: "gpt-4o", // Use GPT-4 Vision for now, will upgrade to GPT-5 when available
      temperature,
      max_tokens: 2000,
      // Use JSON schema if available, otherwise fall back to JSON object format
      ...(jsonSchema ? { 
        response_format: { type: "json_object" }
      } : {}),
      messages: [
        { role: "system", content: system },
        {
          role: "user",
          content: [
            { type: "text", text: userText },
            { 
              type: "image_url", 
              image_url: { 
                url: `data:image/png;base64,${imageBase64}`,
                detail: "high"
              } 
            }
          ]
        }
      ]
    });

    const raw = response.choices[0]?.message?.content ?? "{}";
    return JSON.parse(raw) as T;
  }

  private async runVisionWithStricterPrompt<T>(args: VisionArgs): Promise<T> {
    // Retry with a stricter reminder about JSON output
    const stricterArgs = {
      ...args,
      userText: `${args.userText}\n\nIMPORTANT: Return ONLY valid JSON matching the schema. No prose, no explanations, just the JSON object.`,
    };
    
    return this.callVisionAPI(stricterArgs);
  }

  private generateCacheKey(args: VisionArgs): string {
    const { imageBase64, userText, jsonSchema } = args;
    // Simple hash for now - in production you might want to use a proper crypto library
    const hash = this.simpleHash(imageBase64 + userText + JSON.stringify(jsonSchema));
    return `vision_${hash}`;
  }

  private simpleHash(str: string): string {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32-bit integer
    }
    return Math.abs(hash).toString(36);
  }

  // Cache management
  clearCache(): void {
    this.cache.clear();
  }

  getCacheSize(): number {
    return this.cache.size;
  }
}

export const visionClient = new VisionClient();
