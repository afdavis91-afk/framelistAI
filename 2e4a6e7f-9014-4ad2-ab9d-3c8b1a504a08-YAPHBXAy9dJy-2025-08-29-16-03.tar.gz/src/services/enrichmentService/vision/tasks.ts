import { BoundingBox } from "../../../types/construction";

export type VisionTaskType = 'LEGEND' | 'SCHEDULE' | 'CALLOUT' | 'NOTE' | 'PLAN_TILE';

export interface VisionTask {
  type: VisionTaskType;
  priority: number;
  cropArea: BoundingBox;
  sheetId: string;
  expectedContent: string;
  taskSpecific: {
    legend?: { wallTypes: string[] };
    schedule?: { scheduleType: string; expectedColumns: string[] };
    callout?: { targetDetail: string; targetSheet: string };
    note?: { noteType: string; context: string };
    planTile?: { focusArea: string; elements: string[] };
  };
}

export interface VisionTaskResult {
  task: VisionTask;
  result: any;
  confidence: number;
  conflicts: string[];
  processingTime: number;
  cacheHit: boolean;
}

export interface VisionAnalysisContext {
  projectId: string;
  documentId: string;
  sheetId: string;
  knownWallTypes: string[];
  knownSchedules: string[];
  scale: number;
  level: string;
}

export function createLegendTask(
  sheetId: string,
  cropArea: BoundingBox,
  expectedWallTypes: string[],
  priority: number = 5
): VisionTask {
  return {
    type: 'LEGEND',
    priority,
    cropArea,
    sheetId,
    expectedContent: `Wall type legend with types: ${expectedWallTypes.join(', ')}`,
    taskSpecific: {
      legend: {
        wallTypes: expectedWallTypes
      }
    }
  };
}

export function createScheduleTask(
  sheetId: string,
  cropArea: BoundingBox,
  scheduleType: string,
  expectedColumns: string[],
  priority: number = 4
): VisionTask {
  return {
    type: 'SCHEDULE',
    priority,
    cropArea,
    sheetId,
    expectedContent: `${scheduleType} schedule with columns: ${expectedColumns.join(', ')}`,
    taskSpecific: {
      schedule: {
        scheduleType,
        expectedColumns
      }
    }
  };
}

export function createCalloutTask(
  sheetId: string,
  cropArea: BoundingBox,
  targetDetail: string,
  targetSheet: string,
  priority: number = 3
): VisionTask {
  return {
    type: 'CALLOUT',
    priority,
    cropArea,
    sheetId,
    expectedContent: `Callout note referencing ${targetDetail} on ${targetSheet}`,
    taskSpecific: {
      callout: {
        targetDetail,
        targetSheet
      }
    }
  };
}

export function createPlanTileTask(
  sheetId: string,
  cropArea: BoundingBox,
  focusArea: string,
  expectedElements: string[],
  priority: number = 2
): VisionTask {
  return {
    type: 'PLAN_TILE',
    priority,
    cropArea,
    sheetId,
    expectedContent: `Plan tile focusing on ${focusArea} with elements: ${expectedElements.join(', ')}`,
    taskSpecific: {
      planTile: {
        focusArea,
        elements: expectedElements
      }
    }
  };
}

export function calculateTaskPriority(
  taskType: VisionTaskType,
  confidence: number,
  itemCount: number,
  context: VisionAnalysisContext
): number {
  let basePriority = 0;

  // Base priority by type
  switch (taskType) {
    case 'LEGEND':
      basePriority = 5; // High priority - affects many items
      break;
    case 'SCHEDULE':
      basePriority = 4; // High priority - quantitative data
      break;
    case 'CALLOUT':
      basePriority = 3; // Medium priority - reference resolution
      break;
    case 'NOTE':
      basePriority = 2; // Lower priority - supplementary info
      break;
    case 'PLAN_TILE':
      basePriority = 1; // Lowest priority - detailed analysis
      break;
  }

  // Boost priority for high-confidence areas
  if (confidence > 0.8) {
    basePriority += 2;
  } else if (confidence > 0.6) {
    basePriority += 1;
  }

  // Boost priority for areas affecting many items
  if (itemCount > 10) {
    basePriority += 2;
  } else if (itemCount > 5) {
    basePriority += 1;
  }

  // Boost priority for critical construction elements
  if (context.level === 'foundation' || context.level === 'structural') {
    basePriority += 1;
  }

  return Math.min(basePriority, 10); // Cap at 10
}

export function shouldProcessVisionTask(
  task: VisionTask,
  baselineConfidence: number,
  itemCount: number
): boolean {
  // Always process high-priority tasks
  if (task.priority >= 7) {
    return true;
  }

  // Process if baseline confidence is low and task could help
  if (baselineConfidence < 0.6 && task.priority >= 4) {
    return true;
  }

  // Process if many items are affected
  if (itemCount > 5 && task.priority >= 3) {
    return true;
  }

  // Skip low-priority tasks with good baseline confidence
  if (baselineConfidence > 0.8 && task.priority <= 2) {
    return false;
  }

  return task.priority >= 3;
}
