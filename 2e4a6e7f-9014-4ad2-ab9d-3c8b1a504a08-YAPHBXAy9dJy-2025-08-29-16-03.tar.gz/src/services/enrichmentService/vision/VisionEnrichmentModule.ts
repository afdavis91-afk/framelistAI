import {
  TakeoffLineItem,
  EnrichmentContext,
  TakeoffFlag,
  EnrichmentModule,
  EnrichmentResult,
  EvidenceReference,
} from "../../../types/construction";
import { visionClient } from "./VisionClient";
import { buildSystemPolicy } from "./buildSystemPolicy";

// Pipeline integration imports
import { appendEvidence, appendFlag, type MaybeCtx } from "../../../pipeline";
import {
  promptForHeaderSchedule,
  promptForWallLegend,
  promptForDoorWindowSchedule,
  promptForCalloutNote,
  promptForPlanTile,
  promptForJoistSchedule,
  promptForRafterSchedule,
  promptForBeamSchedule,
  promptForFramingPlan,
  promptForConnectorSchedule,
} from "./buildUserPrompt";
import {
  VisionTask,
  VisionTaskType,
  createLegendTask,
  createScheduleTask,
  createCalloutTask,
  createPlanTileTask,
  calculateTaskPriority,
  shouldProcessVisionTask,
  VisionAnalysisContext,
} from "./tasks";

export class VisionEnrichmentModule implements EnrichmentModule {
  name = "VisionEnrichment";

  async process(
    lineItems: TakeoffLineItem[],
    context: EnrichmentContext,
    onProgress?: (progress: number) => void,
    pipelineContext?: MaybeCtx
  ): Promise<EnrichmentResult> {
    // Check if vision analysis is enabled in settings
    let enableVision = true;
    try {
      const { useSettingsStore } = await import("../../../state/settingsStore");
      enableVision = useSettingsStore.getState().enableVisionAnalysis;
    } catch (e) {
      // If settings store fails to load, enable vision as a safe default
      enableVision = true;
    }

    if (!enableVision) {
      onProgress?.(100);
      return { enrichedLineItems: lineItems, flags: [], confidence: 0 };
    }

    const enriched = [...lineItems];
    const flags: TakeoffFlag[] = [];
    let enhanced = 0;

    onProgress?.(10);

    // Step 1: Identify items that need vision analysis
    const visionTasks = this.identifyVisionTasks(lineItems, context);
    
    if (visionTasks.length === 0) {
      onProgress?.(100);
      return { enrichedLineItems: enriched, flags, confidence: 0 };
    }

    // Append vision task evidence to ledger if available
    if (pipelineContext?.ledger) {
      appendEvidence(pipelineContext, {
        type: "image",
        source: {
          documentId: context.projectDocuments?.[0]?.id || "unknown",
          pageNumber: 1,
          extractor: "VisionEnrichmentModule",
          confidence: 0.8,
        },
        content: {
          visionTasksCount: visionTasks.length,
          taskTypes: visionTasks.map(t => t.type),
          totalTasks: visionTasks.length,
        },
        metadata: {
          contentType: "vision_tasks",
          moduleType: "vision_enrichment",
        },
        timestamp: new Date().toISOString(),
        version: "1.0",
      });
    }

    onProgress?.(20);

    // Step 2: Process vision tasks with concurrency control
    const results = await this.processVisionTasks(visionTasks, context, onProgress);

    onProgress?.(80);

    // Step 3: Apply vision results to line items
    for (const result of results) {
      const enhancedItem = this.applyVisionResult(result, enriched);
      if (enhancedItem) {
        enhanced++;
      }

      // Append vision result evidence to ledger if available
      if (pipelineContext?.ledger) {
        appendEvidence(pipelineContext, {
          type: "image",
          source: {
            documentId: context.projectDocuments?.[0]?.id || "unknown",
            pageNumber: 1,
            extractor: "VisionEnrichmentModule",
            confidence: result.confidence || 0.7,
          },
          content: {
            visionResult: result,
            enhanced: !!enhancedItem,
            taskType: result.taskType,
          },
          metadata: {
            contentType: "vision_result",
            moduleType: "vision_enrichment",
          },
          timestamp: new Date().toISOString(),
          version: "1.0",
        });
      }
    }

    onProgress?.(100);

    return {
      enrichedLineItems: enriched,
      flags,
      confidence: enhanced / Math.max(1, lineItems.length),
    };
  }

  private identifyVisionTasks(
    lineItems: TakeoffLineItem[], 
    context: EnrichmentContext
  ): VisionTask[] {
    const tasks: VisionTask[] = [];

    // Group items by sheet and type to identify vision opportunities
    const sheetGroups = new Map<string, {
      items: TakeoffLineItem[];
      wallTypes: Set<string>;
      schedules: Set<string>;
      callouts: Set<string>;
    }>();

    for (const item of lineItems) {
      const sheetId = item.context.sheetRef || "unknown";
      if (!sheetGroups.has(sheetId)) {
        sheetGroups.set(sheetId, {
          items: [],
          wallTypes: new Set(),
          schedules: new Set(),
          callouts: new Set(),
        });
      }

      const group = sheetGroups.get(sheetId)!;
      group.items.push(item);

      // Categorize items for vision analysis
      if (item.context.scope.toLowerCase().includes("wall")) {
        group.wallTypes.add(item.context.wallType || "unknown");
      }
      if (item.context.scope.toLowerCase().includes("header") || item.context.scope.toLowerCase().includes("beam")) {
        group.schedules.add("header");
      }
      if (item.context.scope.toLowerCase().includes("door") || item.context.scope.toLowerCase().includes("window")) {
        group.schedules.add("door_window");
      }
      if (item.context.scope.toLowerCase().includes("joist")) {
        group.schedules.add("joist");
      }
      if (item.context.scope.toLowerCase().includes("rafter")) {
        group.schedules.add("rafter");
      }
      if (item.context.scope.toLowerCase().includes("connector") || item.context.scope.toLowerCase().includes("hanger")) {
        group.schedules.add("connector");
      }
    }

    // Create vision tasks for each sheet
    for (const [sheetId, group] of sheetGroups) {
      const analysisContext: VisionAnalysisContext = {
        projectId: context.baselineAnalysis?.projectInfo?.name || "unknown",
        documentId: sheetId,
        sheetId,
        knownWallTypes: Array.from(group.wallTypes),
        knownSchedules: Array.from(group.schedules),
        scale: 1, // TODO: Extract from drawing analysis
        level: group.items[0]?.context.level || "unknown",
      };

      // Create wall legend task if we have wall types
      if (group.wallTypes.size > 0) {
        const priority = calculateTaskPriority(
          'LEGEND',
          this.calculateAverageConfidence(group.items),
          group.items.length,
          analysisContext
        );

        if (shouldProcessVisionTask({ type: 'LEGEND', priority } as VisionTask, 
            this.calculateAverageConfidence(group.items), group.items.length)) {
          tasks.push(createLegendTask(
            sheetId,
            this.estimateLegendCropArea(),
            Array.from(group.wallTypes),
            priority
          ));
        }
      }

      // Create schedule tasks
      for (const scheduleType of group.schedules) {
        const priority = calculateTaskPriority(
          'SCHEDULE',
          this.calculateAverageConfidence(group.items),
          group.items.length,
          analysisContext
        );

        if (shouldProcessVisionTask({ type: 'SCHEDULE', priority } as VisionTask,
            this.calculateAverageConfidence(group.items), group.items.length)) {
          const expectedColumns = this.getExpectedColumnsForSchedule(scheduleType);
          tasks.push(createScheduleTask(
            sheetId,
            this.estimateScheduleCropArea(scheduleType),
            scheduleType,
            expectedColumns,
            priority
          ));
        }
      }
    }

    // Sort by priority and limit concurrent tasks
    return tasks
      .sort((a, b) => b.priority - a.priority)
      .slice(0, 5); // Limit to top 5 tasks
  }

  private async processVisionTasks(
    tasks: VisionTask[],
    context: EnrichmentContext,
    onProgress?: (progress: number) => void
  ): Promise<any[]> {
    const results: any[] = [];
    
    // Process with concurrency control
    const concurrency = 3;
    const chunks = this.chunkArray(tasks, concurrency);

    for (let i = 0; i < chunks.length; i++) {
      const chunk = chunks[i];
      const chunkResults = await Promise.all(
        chunk.map(task => this.processSingleVisionTask(task, context))
      );
      
      results.push(...chunkResults);
      onProgress?.(20 + ((i + 1) / chunks.length) * 60);
    }

    return results;
  }

  private async processSingleVisionTask(
    task: VisionTask,
    context: EnrichmentContext
  ): Promise<any> {
    try {
      // For now, we'll use mock image data since we don't have the cropper implemented yet
      // In the real implementation, you would use your HighResCropper here
      const mockImageBase64 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==";

      // Build task-specific prompt
      const { text, schema } = this.buildTaskPrompt(task);
      const systemPolicy = buildSystemPolicy();

      // Run vision analysis
      const result = await visionClient.runVision({
        system: systemPolicy,
        userText: text,
        imageBase64: mockImageBase64,
        jsonSchema: schema,
        temperature: 0,
      });

      return {
        task,
        result,
        confidence: (result as any).confidence || 0.5,
        conflicts: [],
        evidence: {
          documentId: task.sheetId,
          pageNumber: 1,
          coordinates: [task.cropArea.x, task.cropArea.y, task.cropArea.width, task.cropArea.height],
          description: `Vision analysis: ${task.type} with ${Math.round(((result as any).confidence || 0.5) * 100)}% confidence`,
        },
      };

    } catch (error) {
      console.warn(`[VisionEnrichment] Task failed:`, error);
      return {
        task,
        result: null,
        confidence: 0,
        conflicts: [`Vision analysis failed: ${error instanceof Error ? error.message : "Unknown error"}`],
        evidence: {
          documentId: task.sheetId,
          pageNumber: 1,
          coordinates: [0, 0, 0, 0],
          description: "Vision analysis failed",
        },
      };
    }
  }

  private buildTaskPrompt(task: VisionTask): { text: string; schema: object } {
    switch (task.type) {
      case 'LEGEND':
        return promptForWallLegend(task.sheetId);
      case 'SCHEDULE':
        if (task.taskSpecific.schedule?.scheduleType === 'header') {
          return promptForHeaderSchedule(task.sheetId);
        } else if (task.taskSpecific.schedule?.scheduleType === 'door_window') {
          return promptForDoorWindowSchedule(task.sheetId);
        } else if (task.taskSpecific.schedule?.scheduleType === 'joist') {
          return promptForJoistSchedule(task.sheetId);
        } else if (task.taskSpecific.schedule?.scheduleType === 'rafter') {
          return promptForRafterSchedule(task.sheetId);
        } else if (task.taskSpecific.schedule?.scheduleType === 'beam') {
          return promptForBeamSchedule(task.sheetId);
        } else if (task.taskSpecific.schedule?.scheduleType === 'connector') {
          return promptForConnectorSchedule(task.sheetId);
        }
        return promptForHeaderSchedule(task.sheetId); // Default fallback
      case 'CALLOUT':
        return promptForCalloutNote(task.sheetId);
      case 'PLAN_TILE':
        return promptForPlanTile(task.sheetId, task.taskSpecific.planTile?.focusArea || 'general');
      default:
        return promptForHeaderSchedule(task.sheetId); // Safe fallback
    }
  }

  private applyVisionResult(result: any, enrichedItems: TakeoffLineItem[]): boolean {
    if (!result.result || result.confidence < 0.4) {
      return false;
    }

    // Find items that could benefit from this vision result
    const relevantItems = enrichedItems.filter(item => 
      item.context.sheetRef === result.task.sheetId &&
      this.isItemRelevantToVisionResult(item, result)
    );

    if (relevantItems.length === 0) {
      return false;
    }

    // Apply vision results to relevant items
    for (const item of relevantItems) {
      const itemIndex = enrichedItems.findIndex(ei => ei.itemId === item.itemId);
      if (itemIndex !== -1) {
        enrichedItems[itemIndex] = this.enhanceItemWithVisionResult(
          enrichedItems[itemIndex],
          result
        );
      }
    }

    return true;
  }

  private isItemRelevantToVisionResult(item: TakeoffLineItem, result: any): boolean {
    const scope = item.context.scope.toLowerCase();
    
    switch (result.task.type) {
      case 'LEGEND':
        return scope.includes("wall") && Boolean(item.context.wallType);
      case 'SCHEDULE':
        if (result.task.taskSpecific.schedule?.scheduleType === 'header') {
          return scope.includes("header") || scope.includes("beam");
        }
        if (result.task.taskSpecific.schedule?.scheduleType === 'door_window') {
          return scope.includes("door") || scope.includes("window");
        }
        if (result.task.taskSpecific.schedule?.scheduleType === 'joist') {
          return scope.includes("joist");
        }
        if (result.task.taskSpecific.schedule?.scheduleType === 'rafter') {
          return scope.includes("rafter");
        }
        if (result.task.taskSpecific.schedule?.scheduleType === 'beam') {
          return scope.includes("beam") || scope.includes("header");
        }
        if (result.task.taskSpecific.schedule?.scheduleType === 'connector') {
          return scope.includes("connector") || scope.includes("hanger");
        }
        return false;
      case 'CALLOUT':
        return scope.includes("detail") || item.context.sourceNotes.length > 0;
      case 'PLAN_TILE':
        return true; // Plan tiles can affect any item
      default:
        return false;
    }
  }

  private enhanceItemWithVisionResult(item: TakeoffLineItem, result: any): TakeoffLineItem {
    const enhancedItem = { ...item };

    // Add vision evidence
    enhancedItem.evidenceRefs = [
      ...enhancedItem.evidenceRefs,
      result.evidence,
    ];

    // Enhance enrichment data
    if (!enhancedItem.enrichmentData) {
      enhancedItem.enrichmentData = {
        specCandidates: [],
        scheduleCandidates: [],
        calloutResolutions: [],
        enrichmentFlags: [],
        confidenceBoost: 0,
      };
    }

    // Add vision-specific enrichment
    enhancedItem.enrichmentData.enrichmentFlags.push({
      type: "EVIDENCE_ENHANCED",
      message: `Enhanced by vision analysis: ${result.task.type} with ${Math.round(result.confidence * 100)}% confidence`,
      severity: "low",
      sheets: [result.task.sheetId],
      moduleSource: this.name,
      resolved: true,
    });

    // Boost confidence based on vision result
    enhancedItem.enrichmentData.confidenceBoost = 
      (enhancedItem.enrichmentData.confidenceBoost || 0) + (result.confidence * 0.1);

    return enhancedItem;
  }

  // Helper methods
  private calculateAverageConfidence(items: TakeoffLineItem[]): number {
    if (items.length === 0) return 0;
    const total = items.reduce((sum, item) => sum + item.confidence, 0);
    return total / items.length;
  }

  private getExpectedColumnsForSchedule(scheduleType: string): string[] {
    switch (scheduleType) {
      case 'header':
        return ['Mark', 'Size', 'Material', 'Notes'];
      case 'door_window':
        return ['Mark', 'Type', 'Size', 'Material', 'Frame', 'Hardware'];
      default:
        return ['Mark', 'Description', 'Size', 'Material'];
    }
  }

  private estimateLegendCropArea(): any {
    // Mock crop area - in real implementation, this would analyze the drawing
    return { x: 0.8, y: 0.1, width: 0.15, height: 0.3 };
  }

  private estimateScheduleCropArea(scheduleType: string): any {
    // Mock crop area - in real implementation, this would analyze the drawing
    return { x: 0.1, y: 0.6, width: 0.8, height: 0.3 };
  }

  private chunkArray<T>(array: T[], chunkSize: number): T[][] {
    const chunks: T[][] = [];
    for (let i = 0; i < array.length; i += chunkSize) {
      chunks.push(array.slice(i, i + chunkSize));
    }
    return chunks;
  }
}
