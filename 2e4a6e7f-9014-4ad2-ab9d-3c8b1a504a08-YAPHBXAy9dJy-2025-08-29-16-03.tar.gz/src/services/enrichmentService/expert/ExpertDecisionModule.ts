import { TakeoffLineItem, DecisionRecord, TakeoffFlag, EnrichmentContext, EvidenceReference } from "../../../types/construction";

// Pipeline integration imports
import { appendDecision, appendFlag, type MaybeCtx } from "../../../pipeline";

export interface ExpertDecisionResult {
  updatedItems: TakeoffLineItem[];
  decisions: DecisionRecord[];
  flags: TakeoffFlag[];
  confidenceDelta: number;
}

export async function runExpertDecisions(
  lineItems: TakeoffLineItem[],
  context: EnrichmentContext,
  minConfidence: number,
  pipelineContext?: MaybeCtx
): Promise<ExpertDecisionResult> {
  const updated: TakeoffLineItem[] = lineItems.map((it) => ({ ...it, material: { ...it.material }, context: { ...it.context }, assumptions: [...it.assumptions] }));
  const decisions: DecisionRecord[] = [];
  const flags: TakeoffFlag[] = [];

  const addDecision = (itemIdx: number, field: string, fromVal: any, toVal: any, confidence: number, rationale: string, refs?: EvidenceReference[]) => {
    if (confidence < minConfidence) return;
    // Apply change
    const item = updated[itemIdx];
    applyFieldUpdate(item, field, toVal);
    const rec: DecisionRecord = {
      id: `dec_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`,
      itemId: item.itemId,
      field,
      from: fromVal,
      to: toVal,
      confidence,
      rationale,
      sheets: [item.context.sheetRef].filter(Boolean) as string[],
      timestamp: new Date().toISOString(),
      refs,
    };
    decisions.push(rec);

    // Append decision to ledger if available
    if (pipelineContext?.ledger) {
      appendDecision(pipelineContext, {
        topic: `expert_decision_${field}`,
        selectedValue: toVal,
        selectedInferenceId: "",
        competingInferences: [],
        justification: `Expert decision: ${rationale}`,
        policyUsed: {
          thresholds: { minConfidence },
          tiebreakers: ["expert_rules"],
          appliedRules: ["expert_decision"],
        },
        timestamp: new Date().toISOString(),
        stage: "expert_decision",
      });
    }

    flags.push({
      type: "ASSUMPTION",
      message: `Decision: ${field} set to ${formatValue(toVal)} (${Math.round(confidence * 100)}%) - ${rationale}`,
      severity: confidence >= 0.9 ? "low" : confidence >= 0.75 ? "medium" : "medium",
      sheets: rec.sheets,
      resolved: true,
    });
  };

  // Simple, safe, high-signal rules
  updated.forEach((item, idx) => {
    const scope = item.context.scope.toLowerCase();

    // Default species and grade if missing
    if (!item.material.species) {
      addDecision(idx, "material.species", item.material.species, "SPF", 0.85, "Regional default species for light framing");
    }
    if (!item.material.grade) {
      addDecision(idx, "material.grade", item.material.grade, "No.2", 0.85, "Default structural grade when unspecified");
    }

    // Sheathing nailing schedule defaults when missing
    if (scope.includes("sheathing")) {
      if (!item.material.edgeSpacing) {
        addDecision(idx, "material.edgeSpacing", item.material.edgeSpacing, "6\"", 0.8, "Typical edge spacing from residential code tables");
      }
      if (!item.material.fieldSpacing) {
        addDecision(idx, "material.fieldSpacing", item.material.fieldSpacing, "12\"", 0.8, "Typical field spacing from residential code tables");
      }
    }

    // Joist hanger default when joist line items are missing hanger type
    if (scope.includes("joist") && !item.material.hangerType) {
      addDecision(idx, "material.hangerType", item.material.hangerType, "joist_hanger", 0.7, "Standard hanger type for joist to ledger/beam connections");
    }

    // Opening header heuristics: rough opening length threshold
    if (scope.includes("opening")) {
      const rough = item.material.length || 0; // inches
      const fromSpec = item.material.spec;
      if (rough >= 72 && (fromSpec === "2x8" || !fromSpec)) {
        const toSpec = rough >= 96 ? "2x12" : "2x10";
        const ply = rough >= 96 ? 3 : 2;
        addDecision(idx, "material.spec", fromSpec, toSpec, rough >= 96 ? 0.82 : 0.78, "Header size inferred from opening width thresholds");
        if (!item.material.plyCount || item.material.plyCount < ply) {
          addDecision(idx, "material.plyCount", item.material.plyCount, ply, 0.8, "Header ply count matched to opening width");
        }
      }
    }
  });

  // Small confidence bump if we fixed specs
  const confidenceDelta = decisions.length > 0 ? Math.min(0.05, decisions.length * 0.0025) : 0;

  return { updatedItems: updated, decisions, flags, confidenceDelta };
}

function applyFieldUpdate(item: TakeoffLineItem, path: string, value: any) {
  const parts = path.split(".");
  let target: any = item as any;
  for (let i = 0; i < parts.length - 1; i++) {
    target = target[parts[i]];
    if (target == null) return;
  }
  target[parts[parts.length - 1]] = value;
}

function formatValue(v: any): string {
  if (typeof v === "string" || typeof v === "number" || typeof v === "boolean") return String(v);
  try { return JSON.stringify(v); } catch { return "value"; }
}
