import { UnitOfMeasure, TakeoffLineItem } from "../types/construction";

// Core pricing types
export interface PricingLocation {
  city: string;
  state: string;
  zipCode?: string;
  costIndex: number; // CCI factor (1.0 = national average)
  region: PricingRegion;
}

export type PricingRegion = 
  | "northeast" 
  | "southeast" 
  | "midwest" 
  | "southwest" 
  | "west" 
  | "pacific";

// Material normalization
export interface MaterialNormalization {
  fromUnit: UnitOfMeasure;
  toUnit: UnitOfMeasure;
  conversionFactor: number;
  assumptions: string[];
}

export interface NormalizedMaterial {
  originalSpec: string;
  normalizedSpec: string;
  originalQuantity: number;
  normalizedQuantity: number;
  originalUnit: UnitOfMeasure;
  normalizedUnit: UnitOfMeasure;
  conversionFactor: number;
  assumptions: string[];
}

// Supplier and pricing data
export interface Supplier {
  id: string;
  name: string;
  type: SupplierType;
  locations: PricingLocation[];
  apiEndpoint?: string;
  reliability: number; // 0-1 score
  averageDeliveryDays: number;
  minimumOrder?: number;
}

export type SupplierType = 
  | "big_box" 
  | "lumber_yard" 
  | "specialty" 
  | "online" 
  | "wholesale";

export interface PriceQuote {
  supplierId: string;
  supplierName: string;
  materialSpec: string;
  quantity: number;
  unit: UnitOfMeasure;
  unitPrice: number;
  totalPrice: number;
  availability: AvailabilityStatus;
  leadTime: number; // days
  validUntil: Date;
  confidence: number; // 0-1 score
  source: PriceSource;
  metadata?: Record<string, any>;
}

export type AvailabilityStatus = 
  | "in_stock" 
  | "limited" 
  | "special_order" 
  | "unavailable";

export type PriceSource = 
  | "api" 
  | "scrape" 
  | "manual" 
  | "estimated" 
  | "historical";

// Dual pricing system
export interface DualPricingRequest {
  lineItem: TakeoffLineItem;
  location: PricingLocation;
  wasteFactorPct: number;
  urgency: PricingUrgency;
  preferredSuppliers?: string[];
}

export type PricingUrgency = "standard" | "rush" | "emergency";

export interface LiveRetailPricing {
  quotes: PriceQuote[];
  bestQuote: PriceQuote;
  averagePrice: number;
  priceRange: {
    min: number;
    max: number;
  };
  marketAvailability: AvailabilityStatus;
  confidence: number;
  lastUpdated: Date;
  supplierCoverage: number; // percentage of suppliers that responded
}

export interface BaselinePricing {
  rsMeansPrice: number;
  cciAdjustedPrice: number;
  historicalTrend: PriceTrend;
  seasonalFactor: number;
  confidence: number;
  dataAge: number; // days since last update
  source: "rsmeans" | "cci" | "historical" | "estimated";
}

export interface PriceTrend {
  direction: "up" | "down" | "stable";
  percentChange: number; // over last 12 months
  volatility: number; // 0-1 score
}

export interface LineItemSnapshot {
  itemId: string;
  material: {
    spec: string;
    grade: string;
    size?: string;
    species?: string;
    treatment?: string;
  };
  category?: string;
}

export interface PricingComparison {
  lineItemId: string;
  materialSpec: string;
  quantity: number;
  unit: UnitOfMeasure;
  location: PricingLocation;
  originalLineItem?: LineItemSnapshot;
  
  // Live retail pricing
  liveRetail: LiveRetailPricing;
  
  // Baseline pricing
  baseline: BaselinePricing;
  
  // Comparison metrics
  delta: {
    absolute: number;
    percentage: number;
    direction: "live_higher" | "baseline_higher" | "equal";
  };
  
  recommendation: PricingRecommendation;
  overallConfidence: number;
  timestamp: Date;
}

export interface PricingRecommendation {
  preferredOption: "live_retail" | "baseline" | "mixed";
  reasoning: string[];
  riskFactors: string[];
  alternativeActions: string[];
}

// Waste factors
export interface WasteFactorRules {
  [materialCategory: string]: {
    defaultPct: number;
    range: {
      min: number;
      max: number;
    };
    factors: {
      projectType: Record<string, number>;
      complexity: Record<string, number>;
      weather: Record<string, number>;
    };
  };
}

// Configuration and preferences
export interface PricingPreferences {
  defaultLocation: PricingLocation;
  preferredSuppliers: string[];
  maxPriceAge: number; // hours
  confidenceThreshold: number; // 0-1
  enableLiveRetail: boolean;
  enableBaseline: boolean;
  wasteFactorOverrides: Record<string, number>;
  budgetBuffer: number; // percentage
}

// API and service interfaces
export interface PricingProvider {
  name: string;
  type: "live_retail" | "baseline";
  isAvailable(): Promise<boolean>;
  getPricing(request: DualPricingRequest): Promise<PriceQuote[]>;
  getSuppliers(location: PricingLocation): Promise<Supplier[]>;
}

export interface PricingCache {
  key: string;
  data: PricingComparison;
  expiresAt: Date;
  hitCount: number;
}

// Error handling
export interface PricingError {
  code: PricingErrorCode;
  message: string;
  provider?: string;
  retryable: boolean;
  details?: Record<string, any>;
}

export type PricingErrorCode = 
  | "NETWORK_ERROR"
  | "API_LIMIT_EXCEEDED" 
  | "INVALID_MATERIAL"
  | "LOCATION_NOT_SUPPORTED"
  | "SUPPLIER_UNAVAILABLE"
  | "PRICE_STALE"
  | "CONFIDENCE_TOO_LOW"
  | "PRICING_FAILED"
  | "BATCH_FAILED";

// Batch processing
export interface BatchPricingRequest {
  lineItems: TakeoffLineItem[];
  location: PricingLocation;
  preferences: PricingPreferences;
  priority: "low" | "normal" | "high";
}

export interface BatchPricingResult {
  requestId: string;
  status: "pending" | "processing" | "completed" | "failed";
  progress: number; // 0-1
  results: PricingComparison[];
  errors: PricingError[];
  startedAt: Date;
  completedAt?: Date;
  summary: {
    totalItems: number;
    successfulItems: number;
    failedItems: number;
    averageConfidence: number;
    totalEstimatedCost: {
      liveRetail: number;
      baseline: number;
      recommended: number;
    };
  };
}

// Export and reporting
export interface PricingReport {
  projectId: string;
  takeoffId: string;
  location: PricingLocation;
  generatedAt: Date;
  summary: BatchPricingResult["summary"];
  comparisons: PricingComparison[];
  recommendations: {
    overall: PricingRecommendation;
    byCategory: Record<string, PricingRecommendation>;
  };
  riskAnalysis: {
    priceVolatility: number;
    supplierRisk: number;
    availabilityRisk: number;
    overallRisk: "low" | "medium" | "high";
  };
}