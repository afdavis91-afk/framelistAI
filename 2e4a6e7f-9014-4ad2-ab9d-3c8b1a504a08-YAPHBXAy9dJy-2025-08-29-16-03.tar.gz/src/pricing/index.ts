import { 
  DualPricingRequest, 
  PricingComparison, 
  BatchPricingRequest, 
  BatchPricingResult,
  PricingPreferences,
  LiveRetailPricing,
  BaselinePricing,
  PricingRecommendation,
  PricingError,
  PriceQuote
} from "./types";
import { TakeoffLineItem } from "../types/construction";
import { liveRetailProvider } from "./providers/liveRetail";
import { rsMeansProvider } from "./providers/rsmeans";
import { getWasteFactor, categorizeMaterial, getCostIndex, getRegionFromState, normalizeMaterial } from "./catalog";

// Main pricing orchestrator - coordinates dual pricing system
export class PricingOrchestrator {
  private requestQueue: Map<string, BatchPricingRequest> = new Map();
  private results: Map<string, BatchPricingResult> = new Map();
  
  // Get dual pricing comparison for a single line item
  async getDualPricing(
    lineItem: TakeoffLineItem,
    preferences: PricingPreferences
  ): Promise<PricingComparison> {
    
    const category = categorizeMaterial(lineItem.itemId, lineItem.material);
    const wasteFactorPct = getWasteFactor(category);
    
    const request: DualPricingRequest = {
      lineItem,
      location: preferences.defaultLocation,
      wasteFactorPct,
      urgency: "standard",
      preferredSuppliers: preferences.preferredSuppliers
    };
    
    try {
      // Get pricing from both providers in parallel
      const [liveQuotes, baselineQuotes] = await Promise.allSettled([
        preferences.enableLiveRetail ? liveRetailProvider.getPricing(request) : Promise.resolve([]),
        preferences.enableBaseline ? rsMeansProvider.getPricing(request) : Promise.resolve([])
      ]);
      
      // Process live retail results
      const liveRetailPricing = this.processLiveRetailQuotes(
        liveQuotes.status === "fulfilled" ? liveQuotes.value : []
      );
      
      // Process baseline results  
      const baselinePricing = await this.processBaselineQuotes(
        baselineQuotes.status === "fulfilled" ? baselineQuotes.value : [],
        request
      );
      
      // Create comparison
      const comparison = this.createComparison(
        lineItem,
        request.location,
        liveRetailPricing,
        baselinePricing
      );
      
      return comparison;
      
    } catch (error) {
      console.error("Pricing error:", error);
      throw new Error(`Failed to get dual pricing: ${error instanceof Error ? error.message : "Unknown error"}`);
    }
  }
  
  // Batch pricing for multiple line items
  async getBatchPricing(batchRequest: BatchPricingRequest): Promise<string> {
    const requestId = `batch_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
    
    this.requestQueue.set(requestId, batchRequest);
    this.results.set(requestId, {
      requestId,
      status: "pending",
      progress: 0,
      results: [],
      errors: [],
      startedAt: new Date(),
      summary: {
        totalItems: batchRequest.lineItems.length,
        successfulItems: 0,
        failedItems: 0,
        averageConfidence: 0,
        totalEstimatedCost: {
          liveRetail: 0,
          baseline: 0,
          recommended: 0
        }
      }
    });
    
    // Process in background
    this.processBatchPricing(requestId);
    
    return requestId;
  }
  
  private async processBatchPricing(requestId: string): Promise<void> {
    const request = this.requestQueue.get(requestId);
    if (!request) return;
    
    const result = this.results.get(requestId)!;
    result.status = "processing";
    
    try {
      const comparisons: PricingComparison[] = [];
      const errors: PricingError[] = [];
      
      for (let i = 0; i < request.lineItems.length; i++) {
        try {
          const comparison = await this.getDualPricing(request.lineItems[i], request.preferences);
          comparisons.push(comparison);
          result.summary.successfulItems++;
        } catch (error) {
          errors.push({
            code: "PRICING_FAILED",
            message: error instanceof Error ? error.message : "Unknown error",
            retryable: true
          });
          result.summary.failedItems++;
        }
        
        result.progress = (i + 1) / request.lineItems.length;
        this.results.set(requestId, result);
      }
      
      // Calculate summary
      if (comparisons.length > 0) {
        result.summary.averageConfidence = comparisons.reduce((sum, c) => sum + c.overallConfidence, 0) / comparisons.length;
        
        comparisons.forEach(c => {
          result.summary.totalEstimatedCost.liveRetail += c.liveRetail.bestQuote.totalPrice;
          result.summary.totalEstimatedCost.baseline += c.baseline.cciAdjustedPrice;
          
          const recommendedPrice = c.recommendation.preferredOption === "live_retail"
            ? c.liveRetail.bestQuote.totalPrice
            : c.baseline.cciAdjustedPrice;
          result.summary.totalEstimatedCost.recommended += recommendedPrice;
        });
      }
      
      result.results = comparisons;
      result.errors = errors;
      result.status = "completed";
      result.completedAt = new Date();
      
    } catch (error) {
      result.status = "failed";
      result.errors.push({
        code: "BATCH_FAILED",
        message: error instanceof Error ? error.message : "Unknown error",
        retryable: false
      });
    }
    
    this.results.set(requestId, result);
  }
  
  private processLiveRetailQuotes(quotes: PriceQuote[]): LiveRetailPricing {
    if (quotes.length === 0) {
      return {
        quotes: [],
        bestQuote: null as any,
        averagePrice: 0,
        priceRange: { min: 0, max: 0 },
        marketAvailability: "unavailable",
        confidence: 0,
        lastUpdated: new Date(),
        supplierCoverage: 0
      };
    }
    
    const prices = quotes.map(q => q.unitPrice);
    const bestQuote = quotes.reduce((best, current) => 
      current.confidence > best.confidence ? current : best
    );
    
    return {
      quotes,
      bestQuote,
      averagePrice: prices.reduce((sum, p) => sum + p, 0) / prices.length,
      priceRange: {
        min: Math.min(...prices),
        max: Math.max(...prices)
      },
      marketAvailability: quotes.some(q => q.availability === "in_stock") ? "in_stock" : "limited",
      confidence: bestQuote.confidence,
      lastUpdated: new Date(),
      supplierCoverage: quotes.length / Math.max(quotes.length, 1)
    };
  }
  
  private async processBaselineQuotes(quotes: PriceQuote[], request: DualPricingRequest): Promise<BaselinePricing> {
    if (quotes.length === 0) {
      return {
        rsMeansPrice: 0,
        cciAdjustedPrice: 0,
        historicalTrend: { direction: "stable", percentChange: 0, volatility: 0 },
        seasonalFactor: 1.0,
        confidence: 0,
        dataAge: 0,
        source: "estimated"
      };
    }
    
    const quote = quotes[0]; // Baseline pricing typically has one quote
    const cciAdjustment = getCostIndex(request.location.state, request.location.city);
    
    return {
      rsMeansPrice: quote.unitPrice,
      cciAdjustedPrice: quote.unitPrice * cciAdjustment,
      historicalTrend: { direction: "stable", percentChange: 0, volatility: 0.1 },
      seasonalFactor: 1.0,
      confidence: quote.confidence,
      dataAge: 30, // Assume 30 days for baseline
      source: "rsmeans"
    };
  }
  
  private createComparison(
    lineItem: TakeoffLineItem,
    location: any,
    liveRetail: LiveRetailPricing,
    baseline: BaselinePricing
  ): PricingComparison {
    const liveRetailTotal = liveRetail.bestQuote ? liveRetail.bestQuote.totalPrice : 0;
    const baselineTotal = baseline.cciAdjustedPrice;
    
    let preferredOption: "live_retail" | "baseline" | "mixed" = "baseline";
    let reasoning: string[] = [];
    
    if (liveRetail.bestQuote && liveRetail.confidence > 0.8) {
      if (liveRetailTotal < baselineTotal * 0.95) {
        preferredOption = "live_retail";
        reasoning.push("Live retail price is significantly lower than baseline");
      } else if (liveRetail.confidence > baseline.confidence) {
        preferredOption = "live_retail";
        reasoning.push("Live retail has higher confidence than baseline");
      }
    }
    
    if (preferredOption === "baseline") {
      reasoning.push("Baseline pricing selected as fallback");
    }
    
    const delta = liveRetailTotal - baselineTotal;
    const deltaDirection: "live_higher" | "baseline_higher" | "equal" = 
      Math.abs(delta) < 0.01 ? "equal" : delta > 0 ? "live_higher" : "baseline_higher";
    
    return {
      lineItemId: lineItem.itemId,
      materialSpec: lineItem.material.spec,
      quantity: lineItem.qty,
      unit: lineItem.uom,
      location,
      originalLineItem: {
        itemId: lineItem.itemId,
        material: lineItem.material
      },
      liveRetail,
      baseline,
      delta: {
        absolute: Math.abs(delta),
        percentage: baselineTotal > 0 ? (Math.abs(delta) / baselineTotal) * 100 : 0,
        direction: deltaDirection
      },
      recommendation: {
        preferredOption,
        reasoning,
        riskFactors: [],
        alternativeActions: []
      },
      overallConfidence: Math.max(liveRetail.confidence, baseline.confidence),
      timestamp: new Date()
    };
  }
  
  async validateLocation(city: string, state: string): Promise<boolean> {
    const costIndex = getCostIndex(state, city);
    const region = getRegionFromState(state);
    return costIndex > 0 && region !== null;
  }
  
  getDefaultPreferences(): PricingPreferences {
    return {
      defaultLocation: {
        city: "Denver",
        state: "CO",
        costIndex: 1.12,
        region: "west"
      },
      preferredSuppliers: [],
      maxPriceAge: 24, // hours
      confidenceThreshold: 0.7,
      enableLiveRetail: true,
      enableBaseline: true,
      wasteFactorOverrides: {},
      budgetBuffer: 10 // 10% buffer
    };
  }
  
  // Clear all caches
  clearAllCaches(): void {
    liveRetailProvider.clearCache();
    rsMeansProvider.clearCache();
  }
}

// Export singleton instance
export const pricingOrchestrator = new PricingOrchestrator();

// Export utility functions
export { 
  categorizeMaterial, 
  normalizeMaterial
};

// Export new robust pricing core
export * from "./SpecKey";
export * from "./Uom";
export * from "./PriceQuote";
export * from "./RegionIndex";
export * from "./Landed";
export * from "./Selector";
export * from "./Blend";
export * from "./Ledger";
export * from "./ProviderRunner";